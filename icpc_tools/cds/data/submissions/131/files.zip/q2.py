n=int(input())

# mat=[n][1]

# for i in range(n):
#     for j in range(n-1):
#         input().split()
def ascisum(str):
    sum=0
    for i in range(len(str)):
        sum+=ord(str[i])
    return sum

mat1=[list(map(ascisum,input().split())) for _ in range(n)]
# print(mat[0][1])
score=[0 for _ in range(n)]

mat2=[[0 for _ in range(n)] for _ in range(n)]
flag=[[0 for _ in range(n)] for _ in range(n)]

for i in range(n):
    for j in range(n-1):
        if i==j:
            flag[i][j]=1
            flag[i][j+1]=1
            mat2[i][j+1]=mat1[i][j]
        else:
            if flag[i][j]==1:
                
                mat2[i][j+1]=mat1[i][j]
                flag[i][j+1]=1
            else:
                mat2[i][j]=mat1[i][j]
                flag[i][j]=1

# for i in range(n):
#     for j in range(n):
#         print(mat2[i][j])

for i in range(n):
    for j in range(i+1,n):
        # print(i,j)
        # print(mat[0][0])
        if mat2[i][j]>mat2[j][i]:
            score[i]+=1
            # print(score[i])
            continue
        if mat2[i][j]==mat2[j][i]:
            score[i]+=1
            score[j]+=1
            continue
        else:
            score[j]+=1
            continue


max=max(score)
for i in range(len(score)):
    if(score[i]==max):
        print(i+13
              )
    

