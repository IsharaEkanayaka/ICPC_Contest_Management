import sys
T = int(input())

for i in range(T):
    p, q = map(int, input().split())
    n = int(input())
    lst = list(map(int, sys.stdin.readline().rstrip("\n").split()))
    total = sum(lst)
    t = (total + p + q - 1) // (p+q)

    print(t)