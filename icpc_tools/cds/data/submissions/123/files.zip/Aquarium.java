import java.util.*;

public class Aquarium {

    public static void main (String []args) {

        int max = 0;
        int ans = 0;

        System.out.print();
        int n = read.nextInt;

        int [] arr = new int [n];

        for (i = 0; i < n; ++i) {
            System.out.print("Heights: ");
            int Heights = read.nextInt;
            arr [i] = Heights;
        }

        for (i = 0; i < n; ++i) {
            [i] - [i+1] = len;
            len < len = max;
        }

        for (i = 0; i < n; ++i) {
            max * max = ans;
        }

        System.out.println(ans);
    }
}