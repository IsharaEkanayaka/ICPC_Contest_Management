import java.util.*;
class TD {
    Scanner sc = new Scanner(System.in);

    int width =  sc.nextInt();
    int height =  sc.nextInt();

    char[][] grid = new char[width][height];

    for (int i = 0; i < width; i++) {
        String line = sc.next();
        grid[i] = line.toCharArray();
    }

    for (int j = 0; j < grid.length; j++) {
        for(int k = 0; k < grid[j].length; k++) {
            System.out.print(grid[j][k] + " ");
        }

        System.out.println();
    }
}