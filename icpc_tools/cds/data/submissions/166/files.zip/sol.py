n = int(input())
arr = list(map(int, input().split()))

sum=0
for i in range(0,n-1,2):
    sum+=max(arr[i],arr[i+1])
    

print(sum)
