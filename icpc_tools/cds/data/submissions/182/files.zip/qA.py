import sys

a = int(input())

for _ in range(a):
    b = int(input())
    inp = sys.stdin.readline
    ls = list(map(int, input().split()))
    
    for idx1, k in enumerate(ls):
        sum = 0
        for idx2, i in enumerate(ls):
            sum = abs(k - i) + sum + 1
                
        print(sum)