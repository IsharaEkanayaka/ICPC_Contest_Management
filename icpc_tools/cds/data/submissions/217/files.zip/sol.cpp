#include <bits/stdc++.h>
using namespace std;

int main(){
    int n,m,k;cin>>n>>m>>k;
    vector<string>grid(n);
    for (int i = 0;i<n;++i){
        cin>>grid[i];
    }
    vector<vector<int>>arr(n,vector<int>(m));
    for (int i = 0;i<n;++i){
        for (int j = 0;j<m;++j){
            if (grid[i][j] == '.'){
                arr[i][j] = 0;
            }
            else arr[i][j] = 1;
        }
    }
    vector<int>dx = {1,-1,0,0};
    vector<int>dy = {0,0,1,-1};
    map<pair<int,vector<vector<int>>>,int>mp;
    int cycle = -1;
    function<void(int)>solve = [&](int i){
        if (i == k + 1)return;
        if (i % 3 != 0 && i % 2 != 0){
            solve(i + 1);
            return;
        }
        if (mp.find(make_pair(i % 3,arr)) != mp.end()){
            int cy = mp[make_pair(i % 3,arr)] - i;
            int p = (k - i) / cy;
            i+= p * cy;
        }
        mp[make_pair(i % 3,arr)] = i;
        if (i % 2 == 0){
            for (int j = 0;j<n;++j){
                for (int p = 0;p<m;++p){
                    if (arr[j][p] == 0){
                        arr[j][p] = 1; 
                    }
                    else{
                        arr[j][p] = 2;
                    }
                }
            }
        }
        else {
            for (int j = 0;j<n;++j){
                for (int p = 0;p<m;++p){
                    if (arr[j][p] != 2)continue;
                    arr[j][p] = 0;
                    for (int q = 0;q<4;++q){
                        int nx = j + dx[q];
                        int ny = p + dy[q];
                        if (nx < 0 || ny < 0 || nx >= n || ny >= m){
                            continue;
                        }
                        if (arr[nx][ny] == 2)continue;
                        arr[nx][ny] = 0;
                    }
                }
            }
        }
        
        solve(i + 1);
    };
    solve(2);
    for (int i = 0;i<n;++i){
        for (int j = 0;j<m;++j){
            if (arr[i][j] == 0)cout<<'.';
            else {
                cout<<'D';
            }
        }
        cout<<'\n';
    }
}