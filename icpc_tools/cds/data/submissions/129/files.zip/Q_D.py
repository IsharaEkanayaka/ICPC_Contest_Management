import sys

def solve():
    input_data = sys.stdin.read().split()

    iterater = iter(input_data)

    T =  int(next(iterater))

    a = []

    for _ in range(T):
        a.append(int(next(iterater)))

    def voilume(list, N):
        m_vol = 0
        for i in range(N):
            for k in range(1, N):
                v = min(list[i],list[k]) * (len(list[i:k]))
                m_vol = max(v, m_vol)


        return m_vol
    

    print(voilume(a, T))

if __name__ == "__main__":
    solve()
