#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vii;
typedef pair<int,int> pi;
typedef tuple<int,int,int> ti;
typedef vector<ll> li;

#define REP(i,a,b) for(int i=a;i<b;i++)
#define F first
#define S second
#define PB push_back
#define LSOne(s) ((s)&(-s))
#define all(x) (x).begin(),(x).end()
#define MP make_pair
#define P push
#define I insert 


const ll INF=INT64_MAX/2;
const int inf=INT32_MAX/2;
const ll M=1e9+7;
const ll MOD=1e9+7;

void solve(){
    int n;cin>>n;
    int a[n+1];
    for(int i = 1; i<=n;i++){
        cin>>a[i];
    }
    ll dp[n+1];
    dp[0] = dp[1] = 0;
    for(int i = 2; i <= n;i++){
        ll cur = 0;
        dp[i] = INF;
        for(int j = i-1; j>=1; j--){
            if(j%2 == 0){
                //connecting to an even || get dp[j+1]
                ll val = dp[j+1] + cur + max(a[i], a[j]);
                dp[i] = min(dp[i], val);
                if(j+1 < i)cur += max(a[j], a[j+1]);
            }
            else{
                //connecting to an odd || get dp[j-1]
                ll val = dp[j-1] + cur + max(a[i], a[j]);
                dp[i] = min(dp[i], val);
            }
        }                
    }
    if(n%2 == 0)cout<<dp[n]<<endl;
    else cout<<dp[n-1] + a[n]<<endl;
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    solve();
}