t = int(input())
answers = []
for i in range(t):
    n = int(input())
    berries = list(map(int,input().split()))
    max= 0
    
    for i in range(n):
        ans = 0
        y = berries[i]
        pairs = []
        for berry in berries:
            if(berry > max): 
                max = berry
            if(y>berry):
                pairs.append([berry,y])
            else:
                pairs.append([y,berry])

        for j in range(1,max+1):
            for k in range(len(pairs)):
                if j >= pairs[k][0] and j <= pairs[k][1]:
                    ans +=1
        print(f"{ans}",end=' ')
   
        


