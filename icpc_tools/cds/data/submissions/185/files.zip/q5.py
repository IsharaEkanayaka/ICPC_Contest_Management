li=list(map(int,input().split()))
n=li[0]
m=li[1]

mat=[list(map(int,input().split())) for _ in range(n)]

cost=0
lis=[]
for i in range(n):
    # print(min(mat[i]))
    cost+=min(mat[i])
    arr=mat[i]
    lis.append(arr.index(min(arr)))

for i in range(m):
    min=100000000
    if i in lis:
        continue
    for j in range(n):
        # print(j,i)
        if mat[j][i] < min:
            min=mat[j][i]
    cost+=min



print(cost)