import sys
import re
# # n =int(sys.stdin.readline())
# arr=[]
# n = int(input())
# for i  in range(n): 
#     # t_name = list(map(int,(input().split())))

#     t_name = int(input())
#     arr.insert(n-(i-1),t_name)
# print(arr)
#     # for name in t_name:
# b=[14,4,5]
# text=''.join(chr(t) for t in b)
    

#     # x.sort()
#     # print(x[n-1])
# print(text)
b=104
print(b)
print(chr(b))

c="A"
print(c)
print(int(c))

