#include <bits/stdc++.h>
using namespace std;

using ll = long long ;
using ld = long double;
const char el = '\n';
const char sp = ' ';
#define ln '\n'
#define v32 vector<int>
#define v64 vector<long long>

const int N=1e3+5;
ll dp[N][N];
ll a[N];
bool done[N][N];
int n;


ll get(int i, int j){
    if(i==n && j==0){
        return 0;
    }
    if(i==n){
        return a[j-1];
    }
    if(done[i][j]){
        // cout<<i<<' '<<j<<' '<<dp[i][j]<<endl;
        return dp[i][j];
    }
    done[i][j]=1;
    dp[i][j]=1e18;
    if(j==0){
        if(i==n-1){
            dp[i][j]=min(dp[i][j], get(n, 0)+a[n-1]);
            // cout<<i<<' '<<j<<' '<<dp[i][j]<<endl;
            return dp[i][j];
        }
        if(i==n-2){
            dp[i][j]=min(dp[i][j], get(n, 0)+max(a[n-1], a[n-2]));
            // cout<<i<<' '<<j<<' '<<dp[i][j]<<endl;
            return dp[i][j];
        }
        dp[i][j]=min(dp[i][j], get(i+2, 0)+max(a[i], a[i+1]));
        dp[i][j]=min(dp[i][j], get(i+3, i+1)+max(a[i+1], a[i+2]));
        dp[i][j]=min(dp[i][j], get(i+3, i+2)+max(a[i], a[i+2]));
        // cout<<i<<' '<<j<<' '<<dp[i][j]<<endl;
        return dp[i][j];
    }
    else{
        ll cur=a[j-1];
        if(i==n-1){
            dp[i][j]=min(dp[i][j], get(n, 0)+max(a[n-1], cur));
            // cout<<i<<' '<<j<<' '<<dp[i][j]<<endl;
            return dp[i][j];
        }
        dp[i][j]=min(dp[i][j], get(i+2, j)+max(a[i], a[i+1]));
        dp[i][j]=min(dp[i][j], get(i+2, i+1)+max(cur, a[i+1]));
        dp[i][j]=min(dp[i][j], get(i+1, 0)+max(cur, a[i]));
    }
    // cout<<i<<' '<<j<<' '<<dp[i][j]<<endl;
    return dp[i][j];
}


void solve(){
    cin>>n;

    for(int i=0; i<n ;i++){
        cin>>a[i];
    }
    cout<<get(0, 0)<<ln;
    

}

int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    int t__=1;
    // cin>>t__;
    while(t__--){
        solve();
    }
    return 0;
}