import sys
def cal():
   n = int(sys.stdin.readline())
   t= list(map(int,sys.stdin.readline().split()) )
   print(n , " " ,t)
   arr=[]
   for _ in range(n):
     arr.append(t)
   

   Time=[]
   for i in range(0,n-1,2):
     T_max =max(arr[i],arr[i+1])
     Time.append(T_max)

     Total = 0
     for j in Time:
       Total  = int(j ) + Total   
     print (Total) 

# if __name__=="__main__":
cal()
