n=int(input())
M=10^9 + 7

for i in range(n):
    n,m,x = map(int, input().split())
    if x<=n*m:
        if n>=x:
            w=m-1
        elif n<x :
            if x%n==0:
                w=m-(x//n)
            else:
                w=m-(x//n)-1
    
        if w>0:
            print(w % M , 1)
        
        else:
            print(0,1)

