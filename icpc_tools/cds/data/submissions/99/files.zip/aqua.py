n=int(input())
arr= list(map(int,input().split()))
# print(arr[0])
max=0
for i in range(n):
    for j in range(i+1,n):
        area=min(arr[i],arr[j])*(j-i)
        if max<area:
            max=area

print(max)