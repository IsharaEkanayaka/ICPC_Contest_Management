#include <bits/stdc++.h>
#define pb push_back
#define mp pake_pair
#define f first
#define s second
#define vi vector<int>
#define vll vector<ll>

using namespace std;
mt19937 rnd(chrono::steady_clock::now().time_since_epoch().count());

typedef long long ll;
typedef long double ld;
const int MOD = 1e9 + 7;
const int I_MAX = INT_MAX;
const int I_MIN = INT_MIN;
const unsigned int UI_MAX = UINT_MAX;
const ll LL_MAX = LLONG_MAX;
const ll LL_MIN = LLONG_MIN;
const unsigned long long ULL_MAX = ULLONG_MAX;

int solve()
{
    int n; cin >> n; 
    vi a(n); 
    for (int i=0; i<n; i++) {

        cin >> a[i];
    }
    ll ans = 0;
    for (int i=0; i<n; i+=2) {
        if (i==n-1) {
            ans += a[i];
        } else {
            ans += max(a[i], a[i+1]);
        }
    }
    cout << ans << endl;
    return 0;
}

int32_t main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    int TET = 1;
    // cin>>TET;

    for (int i = 1; i <= TET; i++)
    {
        if (solve())
        {
            break;
        }
    }
}