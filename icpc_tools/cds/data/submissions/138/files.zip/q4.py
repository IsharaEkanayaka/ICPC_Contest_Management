
import math
n = int(input())

arr = list(map(int, input().strip(" , ")))
print(arr)
# print("len: ", len(armax) 

# for i in range(len(arr)):
#    maxarr=[]
#    if arr[i] > arr[i-1] :
#       max = arr[i]
#       index  = i
#       maxarr.append(i) 
    
      
# #second max 
# max2 = 0
# for j in range(len(arr)):
#    maxarr=[]
#    if (arr[j] > arr[j-1]) & (arr[j] < max):
#       max2 = arr[j]
#       index2  = j
#       maxarr.append(j) 
# print(max2)

# distance
 





# #  multiplicatyio()
# print((y[len(y) - 2]) * dist)




def max():
   for i in range(len(arr)):
    maxarr=[]
    if arr[i] > arr[i-1] :
        max = arr[i]
        index  = i
        maxarr.append(i) 

    if ((arr[i] > arr[i-1]) & (arr[i] < max)):
            max2 = arr[i]
            index2  = i
            # maxarr.append(j)
    dis = (index2 - index)
    area = dis * max2
    return area



# sort max index
# y = (sorted(arr))
# print(y)

# y.pop()
# print(y)
# sec= y[len(y)-1 ]
# print(sec)      

max()