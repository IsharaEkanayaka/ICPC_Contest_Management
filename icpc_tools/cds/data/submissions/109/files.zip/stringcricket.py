def string_to_Ascii(string):
    sum = 0
    for i in string:
        sum+= ord(i)
    return sum

n = int(input())

arr=[]
for i in range(n):
    row = list(map(string_to_Ascii,input().split()))
    arr.append(row)

matrix= [([0] * n) for _ in range(n)]

for i in range(n):
    for j in range(n):
        if j == i:
            continue
        matrix[i][j] = arr[i][0]
        del arr[i][0]

rowpts = [0] * n
for i in range(n):
    for j in range(n):
        if i == j:
            continue
        if matrix[i][j] > matrix[j][i]:
            rowpts[i] = rowpts[i] + 2
        elif matrix[i][j] == matrix[j][i]:
            rowpts[i] = rowpts[i] + 1

maxrw=max(rowpts)

for i in range(n):
    if rowpts[i]==maxrw:
        print(i+1)
