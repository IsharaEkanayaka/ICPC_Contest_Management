import sys
input = sys.stdin.readline
n = int(input())
scores = []
for i in range(n):
    score = input().strip().split()
    scores.append(score)

ans = [0] * n
seen = set()

for i in range(len(scores)):
    for j in range(len(scores[i])):
        s1 = scores[i][j]
        if j >= i:
            temp1 = j+1
            temp2 = i
        else:
            temp1 = j
            temp2 = i -1
        if (i,j) in seen :
            continue
        s2 = scores[temp1][temp2]
        sum1, sum2 = 0,0
        for c in s1:
            sum1 += ord(c)
        
        for c in s2:
            sum2 += ord(c)

        if sum1 == sum2:
            ans[i] += 1
            ans[temp1] += 1

        elif sum1 > sum2:
            ans[i] += 2
        
        else:
            ans[temp1] += 2

        seen.add((i,j))
        seen.add((temp1,temp2))
    
res = []
m = max(ans)
for i in range(n):
    if ans[i] == m:
        res.append(i+1)

res.sort()

if len(res) == 1:
    print(res[0])
else:
    print('\n'.join(map(str,res)))
