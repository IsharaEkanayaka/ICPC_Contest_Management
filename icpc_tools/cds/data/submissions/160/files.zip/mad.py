n = int(input())
x = list(map(int,input().split()))
a = 0
for i in range(0,len(x)-1,2):
    a = a + max(x[i],x[i+1])
if(n%2 ==1 ):
    a = a + x[-1]


print(a)