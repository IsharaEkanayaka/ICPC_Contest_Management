#include <bits/stdc++.h>
using namespace std;
struct edge{
    long long x,y,v;
};
int main(){
    int n,m;cin>>n>>m;
    vector<vector<long long>>adj(n,vector<long long>(m));
    for (int i = 0;i<n;++i){
        for (int j = 0;j<m;++j){
            cin>>adj[i][j];
        }
    }
    vector<vector<long long>>dp(n + 1,vector<long long>((1<<m),1e17));
    dp[0][0] = 0;
    for (int i = 0;i<n;++i){
        vector<long long>cost((1<<m),0);
        for (int j = 0;j<(1<<m);++j){
            for (int k = 0;k<m;++k){
                if (j & (1<<k)){
                    cost[j] += adj[i][k];
                }
            }
        }
        for (int j = 0;j<(1<<m);++j){
            if (dp[i][j] != 1e17){
                //cout<<i<<" "<<j<<" "<<dp[i][j]<<'\n';
                for (int k = 1;k<(1<<m);++k){
                    //cout<<k<<'\n';
                    dp[i + 1][j | k] = min(dp[i][j] + cost[k],dp[i + 1][j | k]);    
                }
            }
        }
    }
    cout<<dp[n][(1<<m) - 1]<<'\n';
}