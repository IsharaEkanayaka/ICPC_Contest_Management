#include <bits/stdc++.h>
using namespace std;

using ll = long long ;
using ld = long double;
const char el = '\n';
const char sp = ' ';
#define ln '\n'
#define v32 vector<int>
#define v64 vector<long long>
const int N=1e6+5;
v32 g[N];
ll val[N];
ll cuts=0;
ll k;

ll dfs(int i, int par){
    multiset<ll> ml;
    ll sm=val[i];
    for(int v: g[i]){
        if(v==par) continue;
        ll d=dfs(v, i);
        sm+=d;
        ml.insert(d);
    }
    while(k<sm){
        ll dd=*ml.rbegin();
        sm-=dd;
        ml.erase(ml.find(dd));
        cuts++;
    }
    return sm;
}





void solve(){
    int n;
    cin>>n;
    ll mn=0;
    for(int i=0; i<n; i++){
        cin>>val[i];
        mn=max(mn, val[i]);
    }

    for(int i=0; i<n-1; i++){
        int a,b;
        cin>>a>>b;
        a--, b--;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    ll l=mn, r=1e18, mid, result=mn;
    while(l<=r){
        mid=l+(r-l)/2;
        cuts=0;
        k=mid;
        dfs(0, -1);
        if(cuts<=2){
            result=mid;
            r=mid-1;
        }
        else l=mid+1;
    }
    cout<<result<<ln;


    
    return;
}

int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    int t__=1;
    // cin>>t__;
    while(t__--){
        solve();
    }
    return 0;
}