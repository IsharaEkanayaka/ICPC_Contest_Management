#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vii;
typedef pair<int,int> pi;
typedef tuple<int,int,int> ti;
typedef vector<ll> li;

#define REP(i,a,b) for(int i=a;i<b;i++)
#define F first
#define S second
#define PB push_back
#define LSOne(s) ((s)&(-s))
#define all(x) (x).begin(),(x).end()

const ll INF=INT64_MAX/2;
const int inf=INT32_MAX/2;
const ll M=1e9+7;
const ll MOD=1e9+7;

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n,m;cin>>n>>m;
    vii a(n,vi(m));
    REP(i,0,n)REP(j,0,m)cin>>a[i][j];
    int k=pow(2,n),kk=pow(2,m);
    vii dp(k,vi(kk,inf));
    dp[0][0]=0;
    REP(i,1,k)REP(j,1,kk){
        REP(x,0,n)REP(y,0,m){
            if((i&(1<<x))&&(j&(1<<y))){
                if(dp[i&(~(1<<x))][j&(~(1<<y))]!=inf)dp[i][j]=min(dp[i][j],dp[i&(~(1<<x))][j&(~(1<<y))]+a[x][y]);
                if(dp[i][j&(~(1<<y))]!=inf)dp[i][j]=min(dp[i][j],dp[i][j&(~(1<<y))]+a[x][y]);
                if(dp[i&(~(1<<x))][j]!=inf)dp[i][j]=min(dp[i][j],dp[i&(~(1<<x))][j]+a[x][y]);
            }
        }
    }
    cout<<dp[k-1][kk-1];
}