#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    int time=0,time2=0;
    vector<int> v(n,0);
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    sort(v.begin(),v.end());
for(int i=0;i<=n;i++){
    if(v[i]==v[i+1]&&i+2<=n-1) swap(v[i+1],v[i+2]);
    time+=max(v[i],v[i+1]);
    i++;
}
for(int i=n-1;i>=0;i--){
    if(v[i]==v[i+1]&&i+2<=n-1) swap(v[i+1],v[i+2]);
    time2+=max(v[i],v[i-1]);
    i--;
}
cout<<min(time,time2);
    return 0;
}
