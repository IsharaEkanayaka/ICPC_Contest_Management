import sys

a = int(input())

team = list()
team_score = list()
score_list = list()

for k in range(a): 
    inp = sys.stdin.readline
    ls = list(map(str, input().split()))
    sum = 0
    for string in ls:
        w_sum = 0
        for word in string:
            w_sum = w_sum + ord(word) 
        score_list.append(w_sum)
        sum = w_sum + sum

    team.append(score_list.copy())
    team_score.append(sum)
    score_list.clear()

cp_score = team_score.copy()
cp_score.sort(reverse=True)
idx = 0


win = list()
for i in range(a):
    win.append(0)

for i in range(a):
    for j in range(i+1, a):
        if team[i][j-1] > team[j][i]:
            win[i] = win[i] + 2
        elif team[i][j-1] == team[j][i] :
            win[i] = win[i] + 1
            win[j] = win[j] + 1
        else:
            win[j] = win[j] + 2



Dwin = win.copy()
Dwin.sort(reverse = True)
won = list()
m = Dwin[0]
while (m in win):
    idx = win.index(m)
    won.append(idx+ 1)
    win[idx] = 0
    print(idx+ 1)
