#include <bits/stdc++.h>
using namespace std;
int main(){
    int test;cin>>test;
    while(test--){
        long long n;cin>>n;
        vector<long long>arr(n);
        for (int i = 0;i<n;++i)cin>>arr[i];
        vector<int>order(n);
        iota(order.begin(),order.end(),0);
        sort(order.begin(),order.end(),[&](int i,int j){
            return arr[i] < arr[j];
        });
        long long sum = 0,sum2 = 0;
        vector<long long >ans(n,0);
        for (int i = 0;i<n;++i){
            sum+=arr[i];
        }
        for (long long i = 0;i<n;++i){
            ans[order[i]] = -(n - i) * arr[order[i]] + sum + n + i * arr[order[i]] - sum2;
            sum2+=arr[order[i]];
            sum-=arr[order[i]];
        }
        for (auto x:ans)cout<<x<<" ";
        cout<<'\n';
    }

}