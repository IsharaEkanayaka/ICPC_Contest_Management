import sys
input = sys.stdin.readline
def solve():
    n = int(input())

    # input_data = sys.stdin.read().split()

    # iterater = iter(input_data)
    arr = [0]*n
    # n = int(next(iterater))

    for _ in range(n):
        arr[_] = list(map(str,input().split()))

    def asci(string):
        x = 0 
        for i in range(len(string)):
            x += ord(string[i])

        return x
    
    for i in range(len(arr)):
        for k in range(len(arr[i])):
            arr[i][k] = asci(arr[i][k])
    for i in range(len(arr)):
        arr[i].insert(i,0)
    
    scores = [0]*n
    for i in range(len(arr)):
        
        for k in range(len(arr[i])):
            if i!= k:
                if arr[i][k]==arr[k][i]:
                    scores[i]+=1
                if arr[i][k]>arr[k][i]:
                    scores[i] += 2
                
    
    x = max(scores)
    win = []
    for u in range(len(scores)):
        if scores[u]==x:
            print(u+1)
   

        

if __name__ == "__main__":
    solve()