import sys
input = sys.stdin.readline
n = int(input())
arr = list(map(int, input().split()))
l,r = 0, n-1
maxx = 0

while l < r:
    vol = min(arr[l], arr[r]) * (r-l)
    maxx = max(vol, maxx)

    if arr[l] == arr[r]:
        r -= 1
    elif arr[r] > arr[l]:
        l += 1
    else:
        r -= 1

print(maxx)