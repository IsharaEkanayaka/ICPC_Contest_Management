li=list(map(int,input().split()))
n=li[0]
m=li[1]

mat=[list(map(int,input().split())) for _ in range(n)]

cost=0
lis=[]
for i in range(n):
    # print(min(mat[i]))
    if(min(mat[i])==0):
        continue
    cost+=min(mat[i])
    arr=mat[i]
    lis.append(arr.index(min(arr)))

for i in range(m):
    min=100000
    if i in lis:
        continue
    # print(i)
    for j in range(n):
        # print(j,i)
        if mat[j][i] ==0:
            continue
        if mat[j][i] < min:
            min=mat[j][i]
    
    cost+=min


print(cost)