#include <bits/stdc++.h>
using namespace std;

using ll = long long ;
using ld = long double;
const char el = '\n';
const char sp = ' ';
#define ln '\n'
#define v32 vector<int>
#define v64 vector<long long>


void solve(){
    int n;
    cin>>n;
    v32 a(n);
    ll sm=0;
    for(int i=0; i<n; i++){
        cin>>a[i];
        sm+=a[i];
    }
    vector<pair<int, int>> vp;
    for(int i=0; i<n;i++){
        vp.push_back({a[i], i});
    }
    sort(vp.begin(), vp.end());
    ll sm1=0;
    vector<int> ans(n );
    for(int i=0; i<n;i ++){
        
        ans[vp[i].second]+=(sm-sm1-sm1)-(0LL+n-i-i)*vp[i].first+n;
        sm1+=vp[i].first;
        
    }
    for(int i=0; i<n;i++){
        cout<<ans[i];
        if(i!=n-1) cout<<' ';
    }
    cout<<ln;


}

int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    int t__=1;
    cin>>t__;
    while(t__--){
        solve();
    }
    return 0;
}