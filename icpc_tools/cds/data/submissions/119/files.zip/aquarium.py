import sys


n = int(sys.stdin.readline().strip())
panels = list(map(int,sys.stdin.readline().strip().split()))

long=[]
for i in range(0,n):
    for j in range(i,n):
        if not i == j:
            long.append((i,j,panels[i],panels[j]))
maximum=0

for j in range(len(long)):
    if maximum<min(long[j][2],long[j][3])*(abs(long[j][1]-long[j][0])):
        maximum=min(long[j][2],long[j][3])*(abs(long[j][1]-long[j][0]))

print(maximum)