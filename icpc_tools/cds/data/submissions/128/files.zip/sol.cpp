#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;cin>>n;
    vector<vector<int>>adj(n);
    vector<long long>arr(n);
    long long mx = 0;
    for (int i = 0;i<n;++i){
        cin>>arr[i];
        mx = max(mx,arr[i]);
    }
    for (int i = 0;i<n - 1;++i){
        int x,y;cin>>x>>y;
        adj[x - 1].push_back(y - 1);
        adj[y - 1].push_back(x - 1);
    }
    long long left = mx,right = 1e16;
    long long pos = 1e16;
    while(left <= right){
        long long mid = (left + right)>>1;
        vector<int>parent(n,-1);
        vector<int>depth(n,0);
        vector<int>score(n,1);
        vector<long long>v = arr;
        function<void(int)>dfs = [&](int u){
            for (auto x:adj[u]){
                if (x != parent[u]){
                    parent[x] = u;
                    depth[x] = depth[u] + 1;
                    dfs(x);
                }
            }
        };
        dfs(0);
        vector<int>order(n);
        iota(order.begin(),order.end(),0);
        sort(order.begin(),order.end(),[&](int i,int j){
            return depth[i] > depth[j];
        });
        for (int i = 0;i<n - 1;){
            int j = i;
            vector<pair<long long,long long>>temp;
            while(j < n && depth[order[i]] == depth[order[j]]){
                temp.push_back({v[order[j]],order[j]});
                ++j;
            }
            sort(temp.begin(),temp.end());
            for (auto x:temp){
                if (v[parent[x.second]] + v[x.second] <= mid){
                    v[parent[x.second]] += v[x.second];
                    score[parent[x.second]] += score[x.second] - 1;
                }
                else{
                    score[parent[x.second]]+= score[x.second];
                }
            }
            i = j;
        }
        // cout<<mid<<'\n';
        // for (auto x:parent){
        //     cout<<x<<" ";
        // }
        // cout<<'\n';
        // for (auto x:score){
        //     cout<<x<<" ";
        // }
        // cout<<'\n';
        // for (auto x:v){
        //     cout<<x<<" ";
        // }
        // cout<<'\n';
        if (score[0] <= 3){
            right = mid - 1;
            pos = mid;
        }
        else {
            left = mid + 1;
        }
    }
    cout<<pos<<'\n';
}