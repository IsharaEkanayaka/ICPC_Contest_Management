test=int(input())


for _ in range(test):
    n=int(input())
    arr = list(map(int, input().split()))
    
    arr_sort = sorted(arr)

    total_sumt=sum(arr)
    left_sum=0
    arr_list={}
    for i in range(n):
        current_num=arr_sort[i]
        sumt=current_num*i-current_num*(n-i)-2*left_sum+total_sumt+n
        left_sum+=current_num
        arr_list[current_num]=sumt
    

    for i in range(n):
        print(arr_list[arr[i]], end=" ")
    print()
    
    