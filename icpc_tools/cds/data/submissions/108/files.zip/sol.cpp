#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;cin>>n;
    vector<long long>arr(n);
    for (int i = 0;i<n;++i)cin>>arr[i];
    vector<long long>order(n);
    iota(order.begin(),order.end(),0);
    sort(order.begin(),order.end(),[&](int i,int j){
        return arr[i] > arr[j];
    });
    multiset<long long>brr;
    long long ans = 0;
    auto calc = [&](long long x,long long y){
        if (x < y){
            return arr[y] * (y - x);
        }
        return arr[y] * (x - y);
    };
    for (int i = 0;i<n;++i){
        if (i == 1){
            long long x = *brr.begin();
            ans = max(ans,calc(x,order[i]));
        }
        else if (i != 0){
            auto x = *brr.begin();
            auto y = *prev(brr.end());
            ans = max(ans,calc(x,order[i]));
            ans = max(ans,calc(y,order[i]));
        }
        brr.insert(order[i]);
    }
    cout<<ans<<'\n';
}