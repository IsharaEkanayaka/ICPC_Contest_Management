import sys

a = int(input())

inp = sys.stdin.readline
ls = list(map(int, input().split()))
t = 0

while(len(ls) > 1):
    if ls[0] > ls[1]:
        t = t + ls[0]
    elif ls[0] < ls[1]:
        t = t + ls[1]
    else:
        t = t + ls[1]
    
    ls = ls[2:]

if len(ls) == 1:
    t = t + ls[0]

print(t)

