import java.util.*;
import java.util.Scanner;

public class D {
    public static void main(String[] args) {
        int ind1= 0;
        int ind2=0;
        int max1=0;
        int max2=0;

        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();

        if(n>1){
            int[] height=new int[n];
            Scanner sc1 = new Scanner(System.in);
            for(int i=2;i<=n;i++){
                height[i]=sc1.nextInt();
            }
            for(int i=0;i<height.length;i++){
                      if(height[i]>max1){
                        height[i]=max1;
                        ind1=i;
                      }else if (height[i]>max2) {
                              height[i]=max2;
                              ind2=i;
                      }
        
            }
            if(ind1>ind2){
                System.out.println((ind2-ind1)*max2);
            }else{
                System.out.println((ind1-ind2)*max1);
            }
            sc1.close();
        }
             sc.close();
    }
    
    
}
