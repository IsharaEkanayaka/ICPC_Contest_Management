n = int(input())
max = 0
x = list(map(int,input().split()))
for i in range(n):
    for j in range(i,n):
        if(i !=j):
            a = min(x[i], x[j])
            volume = a*(i-j)
            if(volume < 0):
                volume = volume * -1
           
            if volume > max:
                
                max = volume
        

print(max)