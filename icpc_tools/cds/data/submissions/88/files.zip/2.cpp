#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vii;
typedef pair<int,int> pi;
typedef tuple<int,int,int> ti;
typedef vector<ll> li;

#define REP(i,a,b) for(int i=a;i<b;i++)
#define F first
#define S second
#define PB push_back
#define LSOne(s) ((s)&(-s))
#define all(x) (x).begin(),(x).end()

const ll INF=INT64_MAX/2;
const int inf=INT32_MAX/2;
const ll M=1e9+7;
const ll MOD=1e9+7;

void solve(){
    int n;cin >>n;
    vector<pair<ll,int>> a(n);
    REP(i,0,n)cin>>a[i].F;
    REP(i,0,n)a[i].S=i;
    sort(all(a));
    vector<ll> psum(n,0);
    psum[0]=a[0].F;
    REP(i,1,n)psum[i]=psum[i-1]+a[i].F;
    vector<pair<int,ll>> ans(n);
    REP(i,0,n){
        ll k=0;
        if(i!=n-1){
            k+=psum[n-1]-psum[i]-a[i].F*(ll)(n-i-1);
        }
        if(i!=0){
            k+=a[i].F*(ll)(i)-psum[i-1];
        }
        ans[i].S=k+n;
        ans[i].F=a[i].S;
    }
    sort(all(ans));
    REP(i,0,n)cout<<ans[i].S<<" ";
    cout<<"\n";
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    int  t;cin >> t;
    REP(i,0,t)solve();
}
/*
3
3
1 4 3
5
1 2 5 7 1
4
1 10 100 1000
*/