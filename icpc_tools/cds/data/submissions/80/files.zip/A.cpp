#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const int MOD = 1e9 + 7;
const ll oo = 1e8;
const int N = 2e5 + 5;

struct Bit {
  int n;  
  vector<int> bit;
  Bit (int m) {
    n = m;
    bit.assign(n, -1);
  }
  void update(int idx, int val) {
    for (int i = idx; i > 0; i -= i & -i) {
      bit[i] = max(bit[i], val);
    }
  }
  int rng(int idx) {
    int mx = -1;
    while (idx < n) {
      mx = max(mx, bit[idx]);
      idx += idx & - idx;
    }
    return mx;
  }
};

struct Bit2 {
  int n;  
  vector<int> bit;
  Bit2 (int m) {
    n = m;
    bit.assign(n, oo);
  }
  void update(int idx, int val) {
    for (int i = idx; i > 0; i -= i & -i) {
      bit[i] = min(bit[i], val);
    }
  }
  int rng(int idx) {
    int mx = n;
    while (idx < n) {
      mx = min(mx, bit[idx]);
      idx += idx & - idx;
    }
    return mx;
  }
};

void solve() {
  int n;
  cin >> n;
  vector<ll> a(n);
  for (auto& ai : a) {
    cin >> ai;
  }
  Bit bit(N);
  ll ans = 0;
  for (int i = n - 1; i >= 0; i--) if (a[i]) {
    auto qr = bit.rng(a[i]);
    bit.update(a[i], i);
    if (qr == -1) continue;
    ans = max(ans, 1LL * (qr - i) * a[i]);
  }
  Bit2 bit2(N);
  for (int i = 0; i < n; i++) if (a[i]) {
    auto qr = bit2.rng(a[i]);
    bit2.update(a[i], i);
    if (qr == oo) continue;
    ans = max(ans, 1LL * (i - qr) * a[i]);
  }
  cout << ans << "\n";
}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int T = 1;
  //cin >> T;
  for (int t = 1; t <= T; t++) {
    //cout << "Case #" << t << ": ";
    solve();
  }
  return 0;
}