#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const int MOD = 1e9 + 7;
const ll oo = 1e12;
const int N = 1e6 + 4;

void solve() {
  int n, m; cin >> n >> m;
  vector<vector<ll>> cost(n, vector<ll>(m));
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      cin >> cost[i][j];
    }
  }
  int tar = (1 << m);
  vector<vector<ll>> dp(n + 2, vector<ll>(tar + 5, -1));
  auto f = [&](auto &&f, int i, int msk) -> ll {
    if (i == n) return (msk == (tar - 1) ? 0LL : oo);
    auto &ans = dp[i][msk];
    if (~ans) return ans;
    ans = oo;
    for (int j = 0; j < m; j++) {
      ans = min(ans, f(f, i + 1, msk | (1 << j)) + cost[i][j]);
    }
    return ans;
  };
  cout << f(f, 0, 0) << "\n";
}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int T = 1;
  //cin >> T;
  for (int t = 1; t <= T; t++) {
    //cout << "Case #" << t << ": ";
    solve();
  }
  return 0;
}