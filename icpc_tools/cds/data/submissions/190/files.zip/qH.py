import sys

a = int(input())

if a != 0: 
    inp = sys.stdin.readline
    lsk = list(map(int, input().split()))
    ls = lsk[:a]
    t = 0

    while(len(ls) > 1):
        if ls[0] > ls[1]:
            t = t + ls[0]
        elif ls[0] < ls[1]:
            t = t + ls[1]
        else:
            t = t + ls[1]
        
        ls = ls[2:]

    if len(ls) == 1:
        t = t + ls[0]

    print(t)

else: 
    print(0)

    