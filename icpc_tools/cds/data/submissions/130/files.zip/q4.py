
import math
n = int(input())

arr = list(map(int, input().strip(" , ")))
print(arr)
# print("len: ", len(armax) 

# for i in range(len(arr)):
#    maxarr=[]
#    if arr[i] > arr[i-1] :
#       max = arr[i]
#       index  = i
#       maxarr.append(i) 
    
      
#second max 
# max2 = 0
# for j in range(len(arr)):
#    maxarr=[]
#    if (arr[j] > arr[j-1]) & (arr[j] < max):
#       max2 = arr[j]
#       index2  = j
#       maxarr.append(j) 
# print(max2)

# distance
 





# #  multiplicatyio()
# print((y[len(y) - 2]) * dist)




def max(n):
   for i in range(len(arr)):
   
    maxarr=[]
   if arr[i] > arr[i-1] :
      max = arr[i]
      index  = i
      maxarr.append(i) 
      return index    

print(index)


# sort max index
# y = (sorted(arr))
# print(y)

# y.pop()
# print(y)
# sec= y[len(y)-1 ]
# print(sec)      