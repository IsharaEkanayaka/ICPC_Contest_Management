#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const int MOD = 1e9 + 7;
const ll oo = 1e8;
const int N = 1e6 + 4;

void solve() {
  int n;  cin >> n;
  vector<int> a(n);
  ll total = 0;
  for (int i = 0; i < n; i++) {
    cin >> a[i];
    total += a[i];
  }
  vector<vector<int>> adj(n);
  for (int i = 0; i < n - 1; i++) {
    int u, v; cin >> u >> v;  u--, v--;
    adj[u].push_back(v);
    adj[v].push_back(u);
  }
  int f = 0;
  vector<ll> sub(n), mx(n);
  auto ok = [&](auto &&ok, int u, int pr, ll m) -> void {
    sub[u] = a[u];
    for (auto v : adj[u]) if (v ^ pr) {
      ok(ok, v, u, m);
      sub[u] += sub[v];
      if (f) return;
    }
    if ((total - sub[u]) <= m && sub[u] <= m) {
      f = 1;
    }
    priority_queue<int> pq;
    for (auto v : adj[u]) if (v ^ pr) {
      pq.push(mx[v]);
      mx[u] = max(mx[u], mx[v]);
    }
    if ((sub[u] - mx[u]) <= m && (total - sub[u]) <= m) f = 1;
    if (sub[u] <= m) {
      mx[u] = sub[u];
    } 
    ll have = total; 
    if (pq.size() > 1) {
      have -= pq.top();
      pq.pop();
      have -= pq.top();
    } else if (pq.size() == 1) {
      have -= pq.top();
    }
    if (have <= m) f = 1;
  };
  ll lo = 0, hi = 1e16;
  while (lo <= hi) {
    ll mid = (lo + hi) / 2;
    f = 0;
    for (int i = 0; i < n; i++) {
      mx[i] = 0;
      sub[i] = 0;
    }
    ok(ok, 0, 0, mid);
    if (f) {
      hi = mid - 1;
    } else {
      lo = mid + 1;
    }
  }
  cout << lo << "\n";
}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int T = 1;
  //cin >> T;
  for (int t = 1; t <= T; t++) {
    //cout << "Case #" << t << ": ";
    solve();
  }
  return 0;
}