import sys
input = sys.stdin.readline
r,c,n = map(int, input().split())
grid = []

for _ in range(r):
    s = input().strip()
    row = []
    for o in s:
        row.append(o)
    grid.append(row)


def explode(g):
    x = []
    for _ in range(r):
        row = []
        for _ in range(c):
            row.append('D')
        x.append(row)
    
    for i in range(r):
        for j in range(c):
            if g[i][j] == 'D':
                x[i][j] = '.'
                for i_off , j_off in [(0,1),(0,-1),(1,0),(-1,0)]:
                    m = i + i_off
                    n = j + j_off
                    if 0 <= m < r and 0 <= n < c:
                        x[m][n] = '.'

    return x

if n == 1:
    for i in range(r):
        print("".join(grid[i]))

elif n % 2 == 0:
    v = []
    for _ in range(r):
        row = []
        for _ in range(c):
            row.append('D')
        v.append(row)
    for i in range(r):
        print("".join(v[i]))

else:
    p = explode(grid)
    q = explode(p)
    if n % 4 == 3:
        for i in range(r):
            print("".join(p[i]))
    elif n % 4 == 1:
        for i in range(r):
            print("".join(q[i]))
