#include <bits/stdc++.h>
using namespace std;

using ll = long long ;
using ld = long double;
const char el = '\n';
const char sp = ' ';
#define ln '\n'
#define v32 vector<int>
#define v64 vector<long long>
#define int long long
const int K=20;

set<pair<int, int>> vis;
const ll in=1e18;
map<pair<int, int>, ll> dist1, dist2;
vector<pair<int, int>>moves= {{2, 1}, {2, -1}, {1, 2}, {-1, 2}, {-2, 1}, {-2, -1}, {-1, -2}, {1, -2}};

void dfs(int i, int j, int minx, int miny, int mxx, int mxy, map<pair<int, int>, ll> &dist){
    queue<pair<int, int>> q;
    dist.clear();
    q.push({i, j});
    for(int ii=minx; ii<=mxx; ii++){
        for(int jj=miny; jj<=mxy; jj++){
            dist[{ii, jj}]=in;
        }
    }
    dist[{i, j}]=0;

    while(!q.empty()){
        auto [curi, curj]=q.front();
        q.pop();
        int dd=dist[{curi, curj}];
        for(auto it: moves){
            int i2=curi+it.first;
            int j2=curj+it.second;
            if(i2>=minx && i2<=mxx && j2>=miny && j2<=mxy){
                if(dist[{i2, j2}]>dd+1){
                    dist[{i2, j2}]=dd+1;
                    q.push({i2, j2});
                }
            }
        }
    }
}


void solve(){
    int n;
    cin>>n;
    n++;
    
    int a1, b1;
    int a2, b2;
    cin>>a1>>b1;
    cin>>a2>>b2;
    dfs(a1, b1, max(0LL, a1-K), max(0LL, b1-K), min(n, a1+K), min(n, b1+K), dist1);
    dfs(a2, b2, max(0LL, a2-K), max(0LL, b2-K), min(n, a2+K), min(n, b2+K), dist2);
    ll ans=1e18;
    for(auto it1: dist1){
        for(auto it2: dist2){
            int x1=it1.first.first;
            int y1=it1.first.second;
            int x2=it2.first.first;
            int y2=it2.first.second;
            int diffx=llabs(x1-x2);
            int diffy=llabs(y1-y2);
            for(auto [dx, dy]: moves){
                if(diffx%abs(dx)==0 && diffy%dy==0 && diffx/abs(dx)==diffy/abs(dy)){
                    ans=min(ans, it1.second+it2.second+diffx/abs(dx));
                }
            }
        }
    }
    cout<<ans<<ln;



}

int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    int t__=1;
    cin>>t__;
    while(t__--){
        solve();
    }
    return 0;
}