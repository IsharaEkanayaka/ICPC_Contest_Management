#include <bits/stdc++.h>
using namespace std;

using ll = long long ;
using ld = long double;
const char el = '\n';
const char sp = ' ';
#define ln '\n'
#define v32 vector<int>
#define v64 vector<long long>


void solve(){
    ll p, q;
    cin>>p>>q;
    int n;
    cin>>n;
    v64 a(n);
    ll sm=0;
    for(int i=0; i<n ;i++){
        cin>>a[i];
        sm+=a[i];
    }
    ll x=(sm+p+q-1)/(p+q);
    cout<<x<<ln;

}

int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    int t__=1;
    cin>>t__;
    while(t__--){
        solve();
    }
    return 0;
}