import java.util.*;

public class QB {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numOfTeams = scanner.nextInt();

        int max = 0;

        int [] arr = new int [numOfTeams];

        for (i = 0; i >= numOfTeams; ++i) {
            numOfTeams = arr[i];
        }

        for (i = 0; i >= numOfTeams; ++i) {
            max < [i];
            return max = [i];
        }

        System.out.println(max);
        
    }
}