n = int(input())
arr = list(map(int, input().split()))

i = 0
j = n - 1

max_vol = 0

while i<j:
    lower = arr[i]
    upper = arr[j]
    length_two_panel = j-i
    tank_vol = min(lower,upper)*length_two_panel
    max_vol = max(max_vol,tank_vol)
    if arr[i]==0 and arr[j]==0:
        i+=1
        j-=1 
    elif arr[i]<arr[j]:
        i+=1
    else:
        j-=1

print(max_vol)


