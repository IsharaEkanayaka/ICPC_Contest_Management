#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vii;
typedef pair<int,int> pi;
typedef tuple<int,int,int> ti;
typedef vector<ll> li;

#define REP(i,a,b) for(int i=a;i<b;i++)
#define F first
#define S second
#define PB push_back
#define LSOne(s) ((s)&(-s))
#define all(x) (x).begin(),(x).end()
#define MP make_pair

const ll INF=INT64_MAX/2;
const int inf=INT32_MAX/2;
const ll M=1e9+7;
const ll MOD=1e9+7;

void solve(){
    int n;cin>>n;
    int arr [n][n-1];
    memset(arr, 0, sizeof(arr));
    for(int i = 0;i<n;i++){
        for(int j = 0; j<n-1; j++){
            string c; cin>>c;
            for(auto x:c)arr[i][j] += (int)x;
            // cout<<arr[i][j]<<" ";
        }
        // cout<<endl;
    }
    vector<pair<int, int> > v;
    // cout<<endl;
    for(int i = 0; i<n;i++)v.PB(MP(0, i));
    for(int i = 0; i< n;i++){
        for(int j = i+1; j<n;j++){
            // cout<<arr[i][j] << " " << arr[j][i]<<endl;
            if(arr[i][j-1] > arr[j][i])v[i].F-=2;
            else if(arr[i][j-1] < arr[j][i])v[j].F-=2;
            else{
                v[i].F --;
                v[j].F --;
            }
        }
    }
    sort(v.begin(), v.end());
    for(int i = 0; i<n;i++){
        if(v[i].F == v[0].F)cout<<v[i].S+1<<endl;
        // cout<<v[i].F<<endl;
    }
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    solve();
}
/*
3 
qK$ OKw 
so^ Bj$ 
Ae^ Rb& 
*/