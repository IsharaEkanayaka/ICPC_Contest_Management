#include <bits/stdc++.h>
using namespace std;

int main(){
    int test;cin>>test;
    while(test--){
        long long p,q;cin>>p>>q;
        int n;cin>>n;
        vector<long long>arr(n);
        for (int i = 0;i<n;++i){
            cin>>arr[i];
        }
        vector<long long>pref(n + 1,0);
        for (int i = 0;i<n;++i){
            pref[i + 1] = pref[i] + arr[i];
        }
        vector<vector<int>>dp(n,vector<int>(1e6,-1));
        function<int(int,int)>solve = [&](int u,int v){  
            int t = max((v + p - 1) / p,(pref[u] - v + q - 1) / q);   
            if (u == n)return t;
            if (dp[u][v] != -1)return dp[u][v];
            return dp[u][v] = min(solve(u + 1,v + arr[u]),solve(u + 1,v));
        };
        cout<<solve(0,0)<<'\n';
    }
}