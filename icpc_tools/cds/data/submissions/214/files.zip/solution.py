n=int(input())

start_x,start_y=list(map(int,input().split()))
final_x,final_y=list(map(int,input().split()))

graphy = []
for i in range(0,n+1):
    graphy.append([10**9]*(n+1))


graphy[start_x][start_y]=0



def dfs(i,j,step):
    if i<0 or j<0 or i>=n or j>=n:
        return 
    if(step>graphy[i][j]):
        return
    
    graphy[i][j]=min(graphy[i][j],step)

    dfs(i+2,j+1,step+1)
    dfs(i+2,j-1,step+1)
    dfs(i-2,j+1,step+1)
    dfs(i-2,j-1,step+1)
    dfs(i+1,j+2,step+1)
    dfs(i+1,j-2,step+1)
    dfs(i-1,j+2,step+1)
    dfs(i-1,j-2,step+1)

dfs(start_x,start_y,0)

if (graphy[final_x][final_y]==10**9):
    print(-1)
else:
    print(graphy[final_x][final_y])

    