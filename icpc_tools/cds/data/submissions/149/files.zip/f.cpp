#include <bits/stdc++.h>
using namespace std;

using ll = long long ;
using ld = long double;
const char el = '\n';
const char sp = ' ';
#define ln '\n'
#define v32 vector<int>
#define v64 vector<long long>

const int N = 13;
int n, m;
ll mt[N+N][N+N];
ll dp[1<<(2*13)];
bool done[1<<(2*13)];
ll type[N+N];
// int dp[N][(1<<N)];

// int rec(int id, int taken){
//     if(id == n){
//         return __builtin_popcount(taken) == m ? 0: 1e9;
//     }

//     if(dp[id][taken] != -1){
//         return dp[id][taken];
//     }

//     int ans = 1e9;
//     for(int j = 0; j < m ; j++){
//         int ntake = taken | (1<<j);
//         ans = min(ans, mt[id][j] + rec(id+1, ntake));
//     }

//     return dp[id][taken] = ans;
// }

// void solve(){
//     cin>>n>>m;
//     for(int i = 0; i < n ; i++){
//         for(int j = 0 ;j < m ; j++){
//             cin>>mt[i][j];
//         }}

//         memset(dp, -1, sizeof(dp));
//     int ans = rec(0, 0);

//     cout<<ans;

    
//     return;
// }

ll get(ll mask){
    if(mask==0) return 0;
    if(done[mask]){
        return dp[mask];
    }
    done[mask]=1;
    dp[mask]=1e18;
    int cur=0;
    while(((mask>>cur)&1)==0){
        cur++;
    }
    // cout<<cur<<endl;
    if(cur<n){
        for(int nxt=0; nxt<m; nxt++){
            ll mask2=mask;
            if((mask2>>(nxt+n))&1){
                mask2-=(1LL<<(nxt+n));
            }
            mask2-=(1<<cur);
            dp[mask]=min(dp[mask], get(mask2)+mt[cur][nxt]);
        }
    }
    else{
        for(int nxt=0; nxt<n; nxt++){
            ll mask2=mask;
            if((mask2>>nxt)&1){
                mask2-=(1LL<<nxt);
            }
            mask2-=(1LL<<cur);
            dp[mask]=min(dp[mask], get(mask2)+mt[nxt][cur-n]);
        }
    }
    return dp[mask];
}

void solve(){
    cin>>n;
    cin>>m;
    for(int i=0; i<n ;i++){
        for(int j=0; j<m; j++){
            cin>>mt[i][j];
        }
    }
    ll ans=get((1<<(n+m))-1);
    cout<<ans<<ln;


}

int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    int t__=1;
    // cin>>t__;
    while(t__--){
        solve();
    }
    return 0;
}