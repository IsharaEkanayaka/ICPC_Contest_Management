n = int(input())

def string(s):
    sum = 0
    for chara in s:
        sum += ord(chara)
    return sum

score_list  = []
for i in range(n):
    score = []
    word = list(input().split(" "))
    for ii in word:
        
        score.append(string(ii))
    score_list.append(score)

result = [0]*(n)

for i in range(n):
    for j in range(n-1):
        if i<=j:
            if score_list[i][j] > score_list[j+1][i]:
                result[i] +=2
            elif score_list[i][j] == score_list[j+1][i]:
                result[i]+=1  
        if i>j:
            if score_list[i][j] > score_list[j][i-1]:
                result[i] +=2
            elif  score_list[i][j] == score_list[j][i-1]:
                result[i]+=1 

max_score = max(result)

for i in range(n):
    if result[i]==max_score:
        print(i+1)








    


