#include <bits/stdc++.h>
using namespace std;

using ll = long long ;
using ld = long double;
const char el = '\n';
const char sp = ' ';
#define ln '\n'
#define v32 vector<int>
#define v64 vector<long long>


void solve(){
    int n;
    cin>>n;
    v32 a(n);
    ll sm=0;
    for(int i=0; i<n; i++){
        cin>>a[i];
        sm+=a[i];
    }
    vector<pair<int, int>> vp;
    for(int i=0; i<n;i++){
        vp.push_back({a[i], i});
    }
    sort(vp.begin(), vp.end());
    // ll sm1=0;
    // vector<int> ans(n );
    // for(int i=0; i<n;i ++){
        
    //     ans[vp[i].second]+=(sm-sm1-sm1)-(0LL+n-i-i)*vp[i].first+n;
    //     sm1+=vp[i].first;
        
    // }
    // for(int i=0; i<n;i++){
    //     cout<<ans[i];
    //     if(i!=n-1) cout<<' ';
    // }
    // cout<<ln;

    vector<ll> pref(n);
    pref[0] = 1;
    for(int i = 1, j = 1, prev = vp[0].first; i < n ; i++, j++){
        pref[i] = pref[i-1] + 1ll*(vp[i].first - prev)*1ll*j + 1;
        prev = vp[i].first;
    };

    vector<ll> suf(n);
    suf[n-1] = 1;
    for(int i = n-2, j = 1, prev= vp[n-1].first; i >= 0; i--, j++){
        suf[i] = suf[i+1] + 1ll*(prev - vp[i].first)*1ll*j + 1;
        prev = vp[i].first;
    };

    vector<ll> ans(n);
    for(int i = 0; i < n ; i++){
        int j = vp[i].second;
        ans[j] = pref[i] + suf[i] - 1;
    }

    for(int i = 0 ; i< n ; i++){
        cout<<ans[i];
        if(i != n-1){
            cout<<sp;
        }
    }

    cout<<el;
}

int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    int t__=1;
    cin>>t__;
    while(t__--){
        solve();
    }
    return 0;
}