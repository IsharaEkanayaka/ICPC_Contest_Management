#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;cin>>n;
    vector<long long>arr(n);
    for (int i = 0;i<n;++i)cin>>arr[i];
    if (n == 0){
        cout<<0<<'\n';
        return 0;
    }
    if (n == 1){
        cout<<1<<'\n';
        return 0;
    }
    vector<vector<long long >>dp(n,vector<long long>(n,-1));
    function<long long(int,int)>solve = [&](int u,int v){
        if (u >= n)return 0LL;
        if (v >= n)return arr[u];
        if (v + 1 >= n){
            return max(arr[u],arr[v]);    
        }
        if (dp[u][v] != -1)return dp[u][v];
        long long res = solve(v + 1,v + 2) + max(arr[u],arr[v]);
        res = min(res,solve(u,v + 2) + max(arr[v],arr[v + 1]));
        res = min(res,solve(v,v + 2) + max(arr[u],arr[v + 1]));
        return dp[u][v] = res;
    };
    cout<<solve(0,1)<<'\n';
}