import java.util.*;
class TD {
    Scanner sc = new Scanner(System.in);

    int width =  sc.nextInt();
    int height =  sc.nextInt();

    char[][] grid = new char[width][height];

    for (int i; i < width; i++) {
        String line = sc.next();
        grid[i] = line.toCharArray();
    }

    
}