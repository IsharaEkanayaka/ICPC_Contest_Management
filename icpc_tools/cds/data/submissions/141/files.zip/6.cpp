#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vii;
typedef pair<int,int> pi;
typedef tuple<int,int,int> ti;
typedef vector<ll> li;

#define REP(i,a,b) for(int i=a;i<b;i++)
#define F first
#define S second
#define PB push_back
#define LSOne(s) ((s)&(-s))
#define all(x) (x).begin(),(x).end()
#define MP make_pair
#define P push

const ll INF=INT64_MAX/2;
const int inf=INT32_MAX/2;
const ll M=1e9+7;
const ll MOD=1e9+7;

void solve(){
    ll p, q;cin>>p>>q;
    ll n;cin>>n;
    ll s[n];
    ll sum = 0;
    for(int i = 0; i<n;i++){
        cin>>s[i];
        sum += s[i];
    }
    set<ll> v = {0};
    queue<ll> que;
    for(int i = 0 ; i < n; i++){
        for(auto x:v)que.P(x+s[i]);
        while(!que.empty()){
            v.insert(que.front());
            que.pop();
        }
    }

    ll ans = sum;
    for(auto x:v){
        ll a = max((x+p-1)/p, (sum-x+q-1)/q);
        ll b = max((x+p-1)/p, (sum-x+q-1)/q);
        ans = min(ans, min(a,b));
    }
    cout<<ans<<endl;
    // ll l=0, r=sum;
    // while(l<r){
    //     ll m = (l+r)/2;
    //     // if works r = m
    //     // else l = m+1
        
    // }

}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t;cin>>t;
    while(t--)solve();
}

/*
4
2 3
3
2 6 7
37 58
1
93
190 90
2
23 97
13 4
4
10 10 2 45
*/