#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const int MOD = 1e9 + 7;
const ll oo = 1e8;
const int N = 1e6 + 4;

void solve() {
  int n;  cin >> n;
  vector<array<int, 2>> a(n);
  for (int i = 0; i < n; i++) {
    cin >> a[i][0];
    a[i][1] = i;
  }
  sort(a.begin(), a.end());
  vector<ll> pref(n + 1);
  for (int i = 0; i < n; i++) {
    pref[i + 1] = pref[i] + a[i][0];
  }
  vector<ll> ans(n);
  for (int i = 0; i < n; i++) {
    // Left
    ll ext = (i * a[i][0]);
    ll sum = pref[i];
    sum = ext - sum + i;
    ans[a[i][1]] = sum;
    // Right
    ll have = n - i - 1;
    sum = pref[n] - pref[i + 1];
    ext = a[i][0] * have;
    sum -= ext;
    sum += have;
    ans[a[i][1]] += sum + 1;
  }
  for (int i = 0; i < n; i++) {
    cout << ans[i] << " \n"[i == n - 1];
  }
}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int T = 1;
  cin >> T;
  for (int t = 1; t <= T; t++) {
    //cout << "Case #" << t << ": ";
    solve();
  }
  return 0;
}