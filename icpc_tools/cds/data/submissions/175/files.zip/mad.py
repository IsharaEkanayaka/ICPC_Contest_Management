n = int(input())
if(n==0):
    print(0)
else:
    x = list(map(float,input().split()))
    a = 0
    for i in range(0,n-1,2):
        a = a + max(x[i],x[i+1])
    if(n%2 ==1 ):
        a = a + x[-1]


    print(round(a))