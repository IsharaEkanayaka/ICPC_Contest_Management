import java.util.Scanner;
public class Aquarium {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number of glass panels: ");
        int x = input.nextInt();
        int A[] = new int[x];

        for(int i=0;i<x;i++){
            System.out.print("Enter the height of the glass: ");
            A[i] = input.nextInt();
        }
        
        int max1=0;
        int max2=0;
        int index1 = 0;
        int index2 = 0;
        int distance = 0;
        
        for(int i=0;i<x;i++){
            if(A[i]>max1){
                max1 = A[i];
                index1 = i;
            }
        }


        for(int i=0;i<x;i++){
            if(A[i]>max2 && A[i]!= max1){
                max2 = A[i];
                index2 = i;
            }
        }

        if(index1>index2){
            distance = index1 - index2;
        }
        else{
            distance = index2 - index1;
        }

        int volume = distance * max2 ;

        System.out.println("water volume is: "+volume);
        input.close();
    }
}
