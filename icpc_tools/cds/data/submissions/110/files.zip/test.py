from collections import defaultdict,deque
def turning_red(traffic,buttons):
    n=len(buttons)
    graph=defaultdict(list)
    light_to_buttons=defaultdict(list)
    for i,b in enumerate(buttons):
      for i in b:
        light_to_buttons[1].append[i]
    for btns in light_to_buttons.values():
        if len(btns)== 2:
            u,v = btns
            graph[u].append(v)
            graph[v].append(u)

    def check_component(start):
        best=float('inf')
        for init in range(3):
            values= {start:init}
            q=deque([start])
            ok = True
            while q and ok:
                u=  q.popleft()
                for v in graph[u]:
                    if v not in values:

                     values[v]= (3- traffic[v]- values[u])% 3
                     q.append(v)
                    elif values[v] != (3-traffic[v] - values[u]) %3:
                       ok = False

                       break
                    if ok:
                       best = min(best,sum(values.values()))

                return best if best != float('inf') else None
            
            total = 0

            for i in range(n):
               res =  check_component(i)

               if res is None:
                  return"impossible"
               total += res

            return total 
                                                    
                     
                   