import sys

a = int(input())


for _ in range(a):
    a, b, c = map(int, input().split())
    
    while (c > 0):
        b = b - 1
        c = c - a
    
    print(b, 1)



