
import math
import sys
n = int(sys.stdin.readline())
arr = list(map(int, input().strip(" , ")))

def max():
   for i in range(len(arr)):
    maxarr=[]
    if arr[i] > arr[i-1] :
        max = arr[i]
        index  = i
        maxarr.append(i) 

    if ((arr[i] > arr[i-1]) & (arr[i] < max)):
            max2 = arr[i]
            index2  = i
            # maxarr.append(j)
    dis = (index2 - index)
    area = dis * max2
    return area



# sort max index
# y = (sorted(arr))
# print(y)

# y.pop()
# print(y)
# sec= y[len(y)-1 ]
# print(sec)      

max()