import java.util.Scanner;

public class aquarium {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        if( n < 2 || n > 100000){
            return;
        }

        int[] intArr = new int[n];

        for(int i = 0; i < n; i++ ){
            int value = sc.nextInt();
            if(value < 0 || value > 10000){
                return;
            }
            intArr[i] = value;
        }

        int max = 0;
        int min = intArr[0];
        for(int i = 0; i < n; i ++){
            if (intArr[i] > max){
                max = intArr[i];
            }

            if (intArr[i] < min){
                min = intArr[i];
            }
        }

       

        int volume = 0;
        if(max > min){
           int h1 = max - min;
           volume = h1*h1;
        }
        else if(max == min){
            int h2 = max;
            volume = h2*h2;
        }
        System.out.println(volume);
    }
    
}

