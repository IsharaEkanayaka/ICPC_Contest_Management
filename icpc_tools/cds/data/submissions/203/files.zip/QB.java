import java.util.*;

public class QB {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numOfTeams = scanner.nextInt();

        int [] arr = new int [numOfTeams];

        for(int i = 0; i < numOfTeams; i++) {
            System.out.println();
            int nb = scanner.nextInt();
            arr[i] = nb;
        }

        int max = 0;

        for (int j = 0; j >= numOfTeams; ++j) {
            numOfTeams = arr[j];
        }

        System.out.println(max);
        
        for (int k = 0; k >= numOfTeams; ++k) {
            if (max < arr[k]) {
                arr[k] = max;
            }
        }

        System.out.println(max);
    }
}
