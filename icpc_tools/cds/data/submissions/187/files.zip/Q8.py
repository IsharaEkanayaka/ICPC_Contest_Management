n = int(input())

arr=list(map(int,input().split()))
a=arr[0]

t=0
sum1=0
if n%2==0:
    while t<n:
        if arr[t]<=arr[t+1]:
            sum1+=arr[t+1]
        else:
            sum1+=arr[t]
        t+=2
else:
    while t<n-1:
        if arr[t]<=arr[t+1]:
            sum1+=arr[t+1]
        else:
            sum1+=arr[t]
        t+=2
        sum1+=arr[n-1]


rev_arr=arr[::-1]
rev_arr.pop()
new_arr=rev_arr[::-1]

r=0
sum2=0
if (n-1)%2==0:
    while r<n-1:
        if new_arr[r]<=new_arr[r+1]:
            sum2+=new_arr[r+1]
        else:
            sum2+=new_arr[r]
        r+=2
else:
    while r<n-2:
        if new_arr[r]<=new_arr[r+1]:
            sum2+=arr[r+1]
        else:
            sum2+=new_arr[r]
        r+=2
        sum2+=new_arr[n-2]

sum2+=a

if sum1<sum2:
    print(sum1)
else:
    print(sum2)