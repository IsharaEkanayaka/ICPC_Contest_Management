#include <bits/stdc++.h>
using namespace std;

void solve() {
  int n;
  cin >> n;

  vector<vector<long long>> grid(n, vector<long long> (n));

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      if (i == j) continue;
      string k;
      cin >> k;
      long long sum = 0;
      for (auto e : k) sum += e;
      grid[i][j] = sum;
    }
  }

  long long mx = 0;
  vector<long long> sum(n);
  for (int i = 0; i < n; i++) {
    for (int j = i + 1; j < n; j++) {
      if (grid[i][j] > grid[j][i]) sum[i] += 2;
      else if (grid[i][j] < grid[j][i]) sum[j] += 2;
      else sum[i]++, sum[j]++;
      mx = max(mx, sum[i]);
      mx = max(mx, sum[j]);
    }
  }
  // cout << mx << endl;
  set<int> st;
  for (int i = 0; i < n; i++) {
    if (sum[i] == mx) st.insert(i + 1);
  }

  for (auto e : st) cout << e << "\n";


}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int T = 1;
  // cin >> T;
  for (int t = 1; t <= T; t++) {
    solve();
  }
  return 0;
}