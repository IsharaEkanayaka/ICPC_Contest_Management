import java.util.Scanner;

public class Question01 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        t=sc.nextInt();

        for(int i=1;i<=t;i++){
            
            Scanner sc1 =new Scanner(System.in);
            n=sc1.nextInt();
            
            for(int j=0;j<n;j++){
                int [][] a=new int [n][n];
                Scanner sc2=new Scanner(System.in);
                x=new Scanner(System.in);
                a[][]={j+1,x};
                
            }
            //int [][]=new int [i][];

        }



        


    }
}

