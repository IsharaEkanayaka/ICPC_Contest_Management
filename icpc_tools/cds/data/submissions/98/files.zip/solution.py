n = int(input())
arr = list(map(int, input().split()))



max_vol = 0

for i in range(n):
    if arr[i]==0:
        continue
    for j in range(i+1,n):
        length = j-i
        lower = arr[i]
        upper = arr[j]
        volume = min(lower,upper)*length
        max_vol = max(max_vol,volume)

print(max_vol)


