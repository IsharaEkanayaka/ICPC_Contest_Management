#include <bits/stdc++.h>
using namespace std;

using ll = long long ;
using ld = long double;
const char el = '\n';
const char sp = ' ';
#define ln '\n'
#define v32 vector<int>
#define v64 vector<long long>

// struct Line {
//     mutable ll k, m, p;
//     bool operator<(const Line& o) const{
//         return k < o.k;
//     }
//     bool operator<(ll x) const {
//         return p<x;
//     }
// };

// struct LineContainer : multiset<Line, less<>> {
//     static const ll inf= LLONG_MAX;
//     ll div(ll a, ll b){
//         return a/b -((a^b)<0 && a%b);}

void solve(){
    int n;
    cin>>n;

    vector<int> a(n);
    for(int i = 0; i < n ; i++){
        cin>>a[i];
    };

    map<int,int> mp;
    ll ans = 0;
    for(int i = 0 ; i < n; i++){
        auto it = mp.lower_bound(a[i]);
        if(it == mp.end()){
            mp[a[i]] = i;
            continue;
        }

        ans = max(ans, 1ll*(i - it->second)*a[i]);

        if(mp.rbegin()-> first < a[i]){
            mp[a[i]]= i;
        }
    }

    mp.clear();
    for(int i = n-1; i >= 0; i--){
        auto it = mp.lower_bound(a[i]);
        
        if(it == mp.end()){
            mp[a[i]] = i;
            continue;
        }
        
        ans = max(ans, 1ll*(it->second - i)*a[i]);
        if(mp.rbegin()->first < a[i]){
            mp[a[i]] = i;
        }
    }

    cout<<ans;

    return ;
    
}

int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    int t__=1;
    // cin>>t__;
    while(t__--){
        solve();
    }
    return 0;
}