#include<bits/stdc++.h>
using namespace std;
int main(){
    int x=0,y=0,a=0,b=0;
    int n;
    cin>>n;
    vector<int> v(n);
    vector<int> v2(n);
    for(int i=0;i<n;i++){
        cin>>v[i];
        v2[i]=v[i];
    }
    sort(v.begin(),v.end());
    int val1=v[n-1];
    int val2= v[n-2];
    int o=3;
    while(val1==val2&&n-o>0){
    val2=v[n-o];
    o++;
    
}
cout<<val1<<" "<<val2<<" "<<endl;

for(int i=0;i<n;i++){
if(val1==v2[i]&&a==0){ x=i;
a++;}
else if(val2==v2[i]) {y=i;
b++;}
}
cout<<abs(x-y)*abs(x-y);
    return 0;
}
