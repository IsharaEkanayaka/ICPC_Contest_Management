def knapsack(heights,values,H):
    n = 2<=n<=100000
    dp = [ [0] * (H + 1) for_in range(n+1)]
    for i in range(1, n+1):
        for h in range(H+1):
            if heights[i-1]<=h:
                dp[i][h] = max(dp[i-1][h],values[i-1]+dp[i-1][h-heights[i-1]])
            else:
                dp[i][h]=dp[i-1][h]
    return dp[n][H]