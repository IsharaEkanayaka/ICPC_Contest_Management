#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const int MOD = 1e9 + 7;
const ll oo = 1e8;
const int N = 1e3 + 4;
ll a[N];
int n;
ll ans = oo;
bitset<N> dp;

ll f(bitset<N> dp) {
  vector<int> id;
  for (int i = 0; i < N; i++) {
    if (dp[i]) {
      id.push_back(i);
    }
    if (id.size() == 3) break;
  }
  int j = id.size();
  if (j == 0) return 0LL;
  ll ans = oo;
  for (int ms = 0; ms < (1 << j); ms++) {
    ll mx = 0;
    if (__builtin_popcount(ms) == 3) continue;
    bitset<N> n_dp = dp;
    for (int k = 0; k < j; k++) if (k & (1 << ms)) {
      mx = max(mx, a[id[k]]);
      n_dp[id[k]] = 0;
    } 
    ans = min(ans, mx + f(n_dp));
  }
  return ans;
}

void solve() {
  cin >> n;
  for (int i = 0; i < n; i++) {
    cin >> a[i];
    dp[i] = 1;
  }
  cout << "dd\n";
  return;
  cout << f(dp) << "\n";
}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int T = 1;
  //cin >> T;
  for (int t = 1; t <= T; t++) {
    //cout << "Case #" << t << ": ";
    solve();
  }
  return 0;
}