#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const int MOD = 1e9 + 7;
const ll oo = 1e8;
const int N = 1e6 + 4;

ll ans = oo;

void calc(deque<int> dq, ll score) {
  // for (auto e : dq) cout << e << " ";
  // cout << endl;
  if (dq.size() == 0) {
    ans = min(ans, score);
    return;
  }
  
  
  if (dq.size() == 1) {
    score += dq.front();
    dq.pop_back();
    calc(dq, score);
    return;
  }
  else if (dq.size() == 2) {
    score += max(dq.front(), dq.back());
    dq.pop_back();
    dq.pop_front();
    calc(dq, score);
    return;
  } else if (dq.size() == 3) {
    vector<int> v = {dq[0], dq[1], dq[2]};
    sort(v.begin(), v.end());
    dq.pop_front();
    dq.pop_front();
    dq.pop_front();

    dq.push_front(v[0]);
    score += v.back();
    calc(dq, score);
    return;
  } else {
    vector<int> v = {dq[0], dq[1], dq[2]};
    sort(v.begin(), v.end());
    dq.pop_front();
    dq.pop_front();
    dq.pop_front();


    // op1
    dq.push_front(v[2]);
    calc(dq, score + v[1]);

    dq.pop_front();
    

    // op2
    dq.push_front(v[0]);
    calc(dq, score + v[2]);
    
    // dq.pop_front();
  }
}

void solve() {
  int n;
  cin >> n;

  deque<int> dq(n);
  for (int i = 0; i < n; i++) {
    cin >> dq[i];
  }

  calc(dq, 0ll);

  cout << ans << "\n";
}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int T = 1;
  //cin >> T;
  for (int t = 1; t <= T; t++) {
    //cout << "Case #" << t << ": ";
    solve();
  }
  return 0;
}