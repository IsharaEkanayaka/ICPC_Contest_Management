n = int(input())
x_list = list(map(int, input().split()))

maxx = 0
dp = [[0]*n for _ in range(n)]
for i in range(n):
    for j in range(n):
        dp[i][j] = (i - j) * min(x_list[i], x_list[j])
        if dp[i][j] > maxx:
            maxx = dp[i][j]

print(maxx)