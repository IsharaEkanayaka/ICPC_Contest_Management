#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;cin>>n;
    vector<vector<long long>>arr(n);
    vector<vector<string>>brr(n);
    for (int i = 0;i<n;++i){
        for (int j = 0;j<n - 1;++j){
            string s;cin>>s;
            //cout<<s<<'\n';
            long long x = 0;
            for (auto y:s){
                x+=int(y);
            }
            //cout<<s<<" "<<x<<'\n';
            arr[i].push_back(x);
            brr[i].push_back(s);
        }
        
    }
    vector<long long>score(n,0);
    long long mx = 0;
    vector<int>cur(n,0);
    for (int i = 0;i<n;++i){
        for (int j = i + 1;j<n;++j){
            //cout<<brr[i][]<<" "<<brr[j][i]<<" "<<i<<" "<<j<<" "<<arr[i][j - i - 1]<<" "<<arr[j][i]<<'\n';
            if (arr[i][cur[i]] == arr[j][cur[j]]){
                score[i] += 1;
                score[j] += 1;
            }
            else if (arr[i][cur[i]] > arr[j][cur[j]]){
                score[i]+=2;
            }
            else{
                score[j]+=2;
            }
            cur[i]++;
            cur[j]++;
        }
    }
    for (int i = 0;i<n;++i)mx = max(mx,score[i]);
    for (int i = 0;i<n;++i){
        //cout<<score[i]<<'\n';
        if (score[i] == mx)cout<<i + 1<<'\n';
    }
}