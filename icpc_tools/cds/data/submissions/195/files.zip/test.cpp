#include<bits/stdc++.h>
using namespace std;
int main(){
   int x=0,y=0,a=0,b=0;
   int t=3;
   int n;
   cin>>n;
   if(n>=2&&n<=pow(10,5)){
   vector<int>v1(n);
   vector<int>v2(n);
   for(int i=0;i<n;i++){
      cin>>v1[i];
      v2[i]=v1[i];

   }
   sort(v1.begin(),v1.end());
   int val1=v1[n-1];
   int val2=v1[n-2];
   while(val1==val2){
      
      val2=v1[n-t];
      t++;

   }
   for(int i=0;i<n;i++){
      if(val1==v2[i]){
         x=i;
         break;
      }
   }
   for(int i=n-1;i>=0;i--){
      if(val2==v2[i]){
         y=i;
         break;
      }
   }
   if((x-y)==0){
      cout<<1;
   }
   else{
      cout<<abs(x-y)*abs(x-y);
   }

   }

}