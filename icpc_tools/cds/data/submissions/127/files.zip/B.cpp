
#include <bits/stdc++.h>
#define pb push_back
#define mp pake_pair
#define f first
#define s second
#define vi vector<int>
#define vll vector<ll>

using namespace std;
mt19937 rnd(chrono::steady_clock::now().time_since_epoch().count());

typedef long long ll;
typedef long double ld;
const int MOD = 1e9 + 7;
const int I_MAX = INT_MAX;
const int I_MIN = INT_MIN;
const unsigned int UI_MAX = UINT_MAX;
const ll LL_MAX = LLONG_MAX;
const ll LL_MIN = LLONG_MIN;
const unsigned long long ULL_MAX = ULLONG_MAX;

int solve()
{
    int n ; cin >> n; 
    vector<vi> g(n+1, vi(n+1));
    vll s(n+1);

    for (int i=1; i<=n; i++) {
        int f=0;
        for (int j=1; j<=n-1; j++) {
            string str; cin >> str;
            int len=str.size();
            int asc=0;
            for (int k=0; k<len; k++) {
                    asc += (int)str[k];
            }
            if (i==j) {
                f=1;
                g[i][j+1] = asc;
            } else {
                if (f==0) {
                    g[i][j] = asc;
                } else {
                    g[i][j+1] = asc;
                }
            }
        }
    }
    for (int i=1; i<=n ; i++) {
        for (int j=1; j<=n; j++) {
            if (i==j) continue;
            if (g[i][j] > g[j][i]) s[i] += 2;
            else if (g[i][j] == g[j][i]) {s[i] += 1; s[j] += 1;}
        }
    }
    ll mx=0;
    int pos=-1;
    for (int i=1; i<=n; i++) {
        if (s[i]>mx) {
            pos=i;
        }
        mx=max(mx, s[i]);
    }
    if (count(s.begin(), s.end(), mx)==1) {
        cout << pos << endl;
    } else {
        for (int i=1; i<=n; i++) {
            if (s[i]==mx) cout << i << endl;
        }
    }
    
    return 0;
}

int32_t main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    int TET = 1;
    // cin>>TET;

    for (int i = 1; i <= TET; i++)
    {
        if (solve())
        {
            break;
        }
    }
}