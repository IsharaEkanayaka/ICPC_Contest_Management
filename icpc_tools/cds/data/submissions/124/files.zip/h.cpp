#include <bits/stdc++.h>
using namespace std;

using ll = long long ;
using ld = long double;
const char el = '\n';
const char sp = ' ';
#define ln '\n'
#define v32 vector<int>
#define v64 vector<long long>


void solve(){
    int n;
    cin>>n;
    v32 a(n);
    for(int i=0; i<n ;i++){
        cin>>a[i];
    }
    sort(a.begin(), a.end());
    reverse(a.begin(), a.end());
    ll ans=0;
    for(int i=0; i<((n/2)*2); i+=2){
        ans+=a[i];
    }
    if(n%2==1){
        ans+=a[n-1];
    }
    cout<<ans<<ln;


}

int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    int t__=1;
    // cin>>t__;
    while(t__--){
        solve();
    }
    return 0;
}