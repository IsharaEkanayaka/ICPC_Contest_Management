import sys

def solve():
    input_data = sys.stdin.read().split()

    iterater = iter(input_data)

    T =  int(next(iterater))

    a = []

    for _ in range(T):
        a.append(int(next(iterater)))
        a.sort(reverse= True)

    if len(a)%2 == 1:
        a.append(0)

    count = 0 

    for k in range(0, len(a), 2):
        count +=a[k]

    print(count)


if __name__ == "__main__":
    solve()

             

    