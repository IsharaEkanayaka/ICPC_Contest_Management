#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vii;
typedef pair<int,int> pi;
typedef tuple<int,int,int> ti;
typedef vector<ll> li;

#define REP(i,a,b) for(int i=a;i<b;i++)
#define F first
#define S second
#define PB push_back
#define LSOne(s) ((s)&(-s))
#define all(x) (x).begin(),(x).end()

const ll INF=INT64_MAX/2;
const int inf=INT32_MAX/2;
const ll M=1e9+7;
const ll MOD=1e9+7;

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    int r,c,n;cin>>r>>c>>n;
    vii a(r,vi(c,0));
    REP(i,0,r)REP(j,0,c){
        char k;cin>>k;
        if(k=='D')a[i][j]=1;
    }
    n%=4;
    if(n==2||n==0){
        REP(i,0,r){
            REP(j,0,c)cout<<'D';
            cout<<"\n";
        }
    }
    else if(n==1){
        REP(i,0,r){
            REP(j,0,c){
                if(a[i][j])cout<<'D';
                else cout<<'.';
            }
            cout<<"\n";
        }
    }
    else{
        vii b(r,vi(c,1));
        REP(i,0,r){
            REP(j,0,c){
                if(a[i][j]==0)continue;
                if(i!=0)b[i-1][j]=0;
                if(i!=r-1)b[i+1][j]=0;
                if(j!=0)b[i][j-1]=0;
                if(j!=c-1)b[i][j+1]=0;
            }
        }
        REP(i,0,r){
            REP(j,0,c){
                if(a[i][j]==1)a[i][j]=0;
                else if(b[i][j]==1)a[i][j]=1;
            }
        }
        REP(i,0,r){
            REP(j,0,c){
                if(a[i][j])cout<<'D';
                else cout<<'.';
            }
            cout<<"\n";
        }
    }
}