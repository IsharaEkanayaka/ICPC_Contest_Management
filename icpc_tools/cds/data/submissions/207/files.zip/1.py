import sys
input = sys.stdin.readline
t = int(input())
for _ in range(t):
    n = int(input())
    arr = list(map(int, input().split()))

    ans = [0] * n

    for i in range(n):
        summ = 0
        for j in range(n):
            
            summ += abs(arr[i] - arr[j]) + 1
        
        ans[i] = summ

    print(" ".join(map(str,ans)))

