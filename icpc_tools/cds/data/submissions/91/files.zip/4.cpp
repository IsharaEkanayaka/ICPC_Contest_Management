#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vii;
typedef pair<int,int> pi;
typedef tuple<int,int,int> ti;
typedef vector<ll> li;

#define REP(i,a,b) for(int i=a;i<b;i++)
#define F first
#define S second
#define PB push_back
#define LSOne(s) ((s)&(-s))
#define all(x) (x).begin(),(x).end()
#define I insert
#define P push
#define MP make_pair

const ll INF=INT64_MAX/2;
const int inf=INT32_MAX/2;
const ll M=1e9+7;
const ll MOD=1e9+7;

void solve(){
    int n;cin>>n;
    ll arr[n];
    set<ll> ms;
    vector<pair<ll, ll> > v;
    for(ll i = 0; i<n;i++){
        cin>>arr[i];
        ms.insert(i);
        v.PB(MP(arr[i], i));
    }
    // for(auto x:ms)cout<<x<<" ";cout<<endl;
    sort(v.begin(), v.end());
    ll ans = 0;
    for(ll i = 0; i<n;i++){
        ll lm = *ms.begin();
        auto it = ms.end();it--;
        ll rm = *it;
        ll mm = v[i].S;
        // cout<<v[i].F<<" -- "<<lm<<" "<<mm<<" "<<rm<<endl;
        ll cur = max(rm-mm, mm-lm) * v[i].F;
        ans = max(ans, cur);
        ms.erase(v[i].S);
    }
    cout<<ans<<endl;
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    solve();
}
/*
9
1 8 6 2 5 4 8 3 7
*/