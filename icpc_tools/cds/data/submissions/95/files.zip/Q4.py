n=int(input())
new_arr=[]
arr=list(map(int,input().split()))
for i in range (n):
    l=1
    for j in range (i+1,n):
        if arr[j]<arr[i]:
            new_arr.append(arr[j]*l)
        else:
            new_arr.append(arr[i]*l)
        l+=1

print(max(new_arr))
    