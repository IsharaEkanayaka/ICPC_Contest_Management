#include <bits/stdc++.h>
using namespace std;



int main (){
    int n;
    cin >> n;

    if(n==0){
        cout << n;
    }else{
        vector<int> x;
        for(int i = 0; i < n-1; i++){
            cin >> x[i];

        }
        long long a =0;
        for (int i =0; i< n-1; i+2){
            a = a + max(x[i], x[i+1]);
            
        }
        if(n%2==1){
            a = a+x[-1];
        }
        cout << a;
    }
}