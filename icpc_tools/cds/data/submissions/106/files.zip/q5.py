import sys

a = int(input())

inp = sys.stdin.readline
ls = list(map(int, input().split()))

vol = list()
for x, i in enumerate(ls):
    br = 0
    for j in ls[x+1:] :
        br = br + 1
        if i < j:
            vol.append(i*br)
        elif j < i:
            vol.append(j*br)
        else:
            vol.append(i*br)

vol.sort(reverse=True)
print(vol[0])

