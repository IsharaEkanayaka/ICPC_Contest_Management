n = int(input())
arr = list(map(int, input().split()))

A = arr[0]
B = arr[1]
min_num = -10**10
for i in range(2,n):
    if A>B:
        B+=arr[i]
    else:
        A+=arr[i]

print(max(A,B))
