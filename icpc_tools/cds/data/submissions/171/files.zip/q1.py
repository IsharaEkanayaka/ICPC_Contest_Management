def getSum(arr,num):
    arr_pair=[]
    for i in arr:
        if i<=num:
            arr_pair.append([i,num])
        else:
            arr_pair.append([num,i])
    
    final_arr = []
    for j in range(1000000000):
        count = 0
        for i in range(len(arr_pair)):
            # print(arr_pair[i])
            # print("valu",arr_pair[i][0],arr_pair[i][1],j)
            if(arr_pair[i][0]<=j+1 and arr_pair[i][1]>=j+1):
                count=count+1
                # print(count)
        
        final_arr.append(count)
        if(final_arr[j]==0):
            break
    
    return sum(final_arr)



def ques1():
    n= int(input())
    arr=list(map(int,input().split()))
    final=[]
    for i in range(len(arr)):
        sum1= getSum(arr,arr[i])
        print(sum1,end=" ")
        # final.append(sum1)

test_case=input()
for i in range(int(test_case)):
    ques1()




