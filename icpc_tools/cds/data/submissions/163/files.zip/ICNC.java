import java.util.*;

public class ICNC {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n=0, m=0;

        int rows = scanner.nextInt();
        int cols = scanner.nextInt();

        int [][] cost = new int[rows][cols];

        for(int i = 0; i < rows; i++) {
            for (int j = 0;  j < cols; j++) {
                cost[i][j] = scanner.nextInt();
            }
        }
    }
}
