n = int(input())
team_scores = []

final_scores =[]
for i in range(n):
    final_scores.append(0)
for i in range(n):
    scores = list(map(str,input().split()))
    current_scores= []
    for score in scores:
        current = 0
        for a in score:
            current += ord(a)
        current_scores.append(current)
    current_scores.insert(i,0)
    
    team_scores.append(current_scores)

for i in range(n):
    for j in range(n):
        if(i!=j):
            if(team_scores[i][j] > team_scores[j][i]):
                final_scores[i] += 1



max = 0
winners = []

sorted_l = sorted(final_scores)
max_score = sorted_l[-1]
for i in range(n):
    if(final_scores[i] == max_score):
        print(i+1)

