import sys
import bisect


n=int(sys.stdin.readline().rstrip("\n"))
def score(word):
    tot=0
    for i in word:
        tot+=ord(i)
    return tot
team_scores=[[0]*(n) for _  in range(n)]
for i in range (0,n):
    scores=list(map(str,sys.stdin.readline().rstrip("\n").split()))
    for j in range(len(scores)):
         team_scores[i][j]+=score(scores[j])

points=[0]*n
for i in range((n+1)//2):
    for j in range(i,n-1):
        if team_scores[i][j]>team_scores[j+1][i]:
            points[i]+=2
        elif team_scores[i][j]==team_scores[j+1][i]:
            points[i]+=1
            points[j+1]+=1
        else:
            points[j+1]+=2
if len(points)!=0:
    high=max(points)


for j in range(n):
    if points[j]>=high:
        print(j+1)
