#include <bits/stdc++.h>
using namespace std;

using ll = long long ;
using ld = long double;
const char el = '\n';
const char sp = ' ';
#define ln '\n'
#define v32 vector<int>
#define v64 vector<long long>
const int N=205;
string s[N][N];

int score(string &s1){
    int sc=0;
    for(int i=0; i<s1.size() ;i++){
        sc+=s1[i];
    }
    return sc;
}

void solve(){
    int n;
    cin>>n;
    for(int i=0; i<n ;i++){
        for(int j=0; j<n; j++){
            if(j==i) continue;
            cin>>s[i][j];
        }
    }
    vector<int> scores(n);

    for(int i=0; i<n ;i++){
        for(int j=i+1 ; j<n; j++){
           
            int sij=score(s[i][j]);
            int sji=score(s[j][i]);
            if(sij>sji){
                scores[i]+=2;
            }
            else if(sij==sji){
                scores[i]++;
                scores[j]++;
            }
            else scores[j]+=2;
        }
    }
    vector<int> winners;
    int maxsc=-1;
    for(int i=0; i<n; i++){
        if(maxsc<scores[i]){
            maxsc=scores[i];
            winners.clear();
        }
        if(maxsc==scores[i]){
            winners.push_back(i+1);
        }
    }
    for(int winner: winners){
        cout<<winner<<ln;
    }
    


    
}

int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    int t__=1;
    // cin>>t__;
    while(t__--){
        solve();
    }
    return 0;
}