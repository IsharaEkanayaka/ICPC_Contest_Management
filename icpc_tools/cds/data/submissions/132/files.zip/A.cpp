#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const int MOD = 1e9 + 7;
const ll oo = 1e8;
const int N = 1e6 + 4;

void solve() {
  ll p, q;  cin >> p >> q;
  int n;  cin >> n;
  bitset<N> dp;
  dp[0] = 1;
  vector<int> a(n);
  ll total = 0;
  for (int i = 0; i < n; i++) {
    cin >> a[i];
    total += a[i];
    dp |= dp << a[i];
  }
  auto ok = [&](ll m) -> int {
    ll bg1 = p * m, bg2 = q * m;
    ll tar = min(bg1, bg2);
    for (int i = 0; i <= tar; i++) if (dp[i]) {
      ll half = total - i;
      if (half <= max(bg1, bg2)) return 1;
    }
    return 0;
  };
  ll lo = 1, hi = 1e6 + 5;
  while (lo <= hi) {
    ll mid = (lo + hi) >> 1;
    if (ok(mid)) {
      hi = mid - 1;
    } else {
      lo = mid + 1;
    }
  }
  cout << lo << "\n";
}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int T = 1;
  cin >> T;
  for (int t = 1; t <= T; t++) {
    //cout << "Case #" << t << ": ";
    solve();
  }
  return 0;
}