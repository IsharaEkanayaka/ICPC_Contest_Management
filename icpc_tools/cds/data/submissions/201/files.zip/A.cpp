#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const int MOD = 1e9 + 7;
const ll oo = 1e8;
const int N = 1e6 + 4;

void solve() {
  int n;
  cin >> n;

  deque<int> dq(n);
  for (int i = 0; i < n; i++) {
    cin >> dq[i];
  }

  long long ans = 0;
  while (dq.size()) {
    if (dq.size() == 1) {
      ans += dq.front();
      dq.pop_front();
    } else if (dq.size() == 2) {
      ans += max(dq.front(), dq.back());
      dq.pop_back();
      dq.pop_back();
    } else if (dq.size() == 3) {
      vector<int> v = {dq[0], dq[1], dq[2]};
      sort(v.begin(), v.end());
      dq.pop_front();
      dq.pop_front();
      dq.pop_front();

      dq.push_front(v[0]);
      ans += v.back();
    } else {
      vector<int> v = {dq[0], dq[1], dq[2]};
      sort(v.begin(), v.end());
      dq.pop_front();
      dq.pop_front();
      dq.pop_front();

      ll op1 = max(v[1], v[0]) + max(v[2], dq.front());
      ll op2 = max(v[1], v[2]) + max(v[0], dq.front());
      if (op1 < op2) {
        ans += max(v[1], v[0]);
        dq.push_front(v[2]);
      } else {
        ans += max(v[1], v[2]);
        dq.push_front(v[0]);
      }
    }
  }

  cout << ans << "\n";
}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int T = 1;
  //cin >> T;
  for (int t = 1; t <= T; t++) {
    //cout << "Case #" << t << ": ";
    solve();
  }
  return 0;
}