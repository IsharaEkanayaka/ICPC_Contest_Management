import java.util.Scanner;
import java.util.*;
import java.util.ArrayList;

public class Questions02 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter teams : ");
        int N = sc.nextInt();
        
        System.out.println("Enter team one mark :");
        String mark1 = sc.nextLine();

        System.out.println("Enter team one mark2 :");
        String mark2 = sc.nextLine();

        int A=65,a=97;

        String len1 = mark1.length();
        String len2 = mark2.length();

        for(int i=0;i<len1;i++){
            
        }
        

    }
}
