#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const int MOD = 1e9 + 7;
const ll oo = 1e17;
const int N = 1e5 + 5;

void solve() {
  int n;
  cin >> n;
  vector<ll> a(n);
  for (auto& ai : a) {
    cin >> ai;
  }
  ll mx = 0, l = 0, r = n - 1;
  while (l <= r) {
    mx = max(mx, min(a[l], a[r]) * (r - l));
    if (a[l] > a[r]) r--;
    else l++;
  }
  cout << mx << '\n';
}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int T = 1;
  //cin >> T;
  for (int t = 1; t <= T; t++) {
    //cout << "Case #" << t << ": ";
    solve();
  }
  return 0;
}