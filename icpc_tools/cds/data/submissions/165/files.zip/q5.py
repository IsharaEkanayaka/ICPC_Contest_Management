

def max():
    
   import math
   import sys
   n = int(sys.stdin.readline())
   arr = list(map(int, input().strip(" ")))

   for i in range(len(arr)):
    maxarr=[]
    if arr[i] > arr[i-1] :
        max = arr[i]
        index  = i
        maxarr.append(i) 

    z = sorted(maxarr)
    index = z[len(z)-1]
    for j in range(len(arr)):
        if (arr[j] > arr[j-1]) & (arr[j] < max):
            max2 = arr[j]
            index2  = j
    # if ((arr[i] > arr[i-1]) & (arr[i] < max)):
    #         max2 = arr[i]
    #         index2  = i
    #         # maxarr.append(j)
    dis = (index2 - index)
    area = dis * max2
    print(area)

if __name__=="__main__" :
 max()


