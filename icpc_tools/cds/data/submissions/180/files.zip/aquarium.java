import java.util.Scanner;

public class aquarium {
    
    public static void main(String[] args) {
      
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int max1 = 0;
        int max2 = 0;
        int capacity = 0;
        int index1 = 0;
        int index2 = 0;
        int h =0;

        System.out.println("Enter number of panels :");
        n=sc.nextInt();
        if(2<= n && n <= 100000){
        System.out.println(" Height:");
        h =sc.nextInt();
        if(h>=0 && h<=10000){

        int[] height = new int[n];
        for(int i =0; i<n; i++ ){
            height[i] = sc.nextInt();
        }

        for(int i=0; i<n;i++){
            if(height[i]>= max1){
                max1= height[i];
                index1 = i;
                
        }
            else {
                max1 = max1;
            }
    }
    
         for(int i=0; i<n;i++){
            if(height[i]>= max2){
                max2= height[i];
                index2 = i;
                
        }
            else {
                max2 = max2;
            }
    }
    if(max1<max2){
      capacity = max1*(index2-index1);
    }
    else
        capacity = max2*(index2-index1);
    System.out.println(capacity);
    }
}
}
}