import sys

def subsum(subs,m):
    sum = 0
    for q in range(1,m + 1):
        count = 0
        for s in subs:
            if (q >= s[0] and q <= s[1]) or (q >= s[1] and q <= s[0]):
                count += 1
        sum = sum + count
    return sum

t = int(sys.stdin.readline().strip())
for i in range(t):
    n = int(sys.stdin.readline().strip())
    arr = list(map(int,sys.stdin.readline().strip().split()))
    m = max(arr)
    for item in arr:
        y = item
        subs = []
        for itm in arr:
            subs.append((y,itm))
        print(subsum(subs,m))