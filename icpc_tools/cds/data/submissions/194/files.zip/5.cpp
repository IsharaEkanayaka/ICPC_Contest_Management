#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vii;
typedef pair<int,int> pi;
typedef tuple<int,int,int> ti;
typedef vector<ll> li;

#define REP(i,a,b) for(int i=a;i<b;i++)
#define F first
#define S second
#define PB push_back
#define LSOne(s) ((s)&(-s))
#define all(x) (x).begin(),(x).end()

const ll INF=INT64_MAX/2;
const int inf=INT32_MAX/2;
const ll M=1e9+7;
const ll MOD=1e9+7;

vector<ll> a,val;
vii b;
vi p;

void dfs(int x){
    for(auto u:b[x]){
        if(u!=p[x]){
            p[u]=x;
            dfs(u);
            val[x]+=val[u];
        }
    }
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n;cin>>n;
    a.resize(n);
    REP(i,0,n)cin>>a[i];
    b.resize(n);
    val.resize(n);
    REP(i,0,n)val[i]=a[i];
    p.resize(n,-1);
    REP(i,0,n-1){
        int x,y;cin>>x>>y;
        x--;y--;
        b[x].PB(y);
        b[y].PB(x);
    }
    if(n<=2){
        cout<<max(a[0],a[1]);
        return 0;
    }
    int root=0;
    while(b[root].size()==1)root++;
    dfs(root);
    REP(i,0,n)if(i!=root)b[i].erase(find(all(b[i]),p[i]));
    int x=b[root][0],y=b[root][1];
    if(val[x]<val[y])swap(x,y);
    for(auto u:b[root]){
        if(u==x||u==y)continue;
        if(val[u]>=val[x]){
            y=x;
            x=u;
        }
        else if(val[u]>val[y])y=u;
    }
    ll p=a[root],q=0,r=0;
    for(auto u:b[root]){
        if(u!=x&&u!=y)p+=val[u];
    }
    if(val[x]<val[y])swap(x,y);
    int xx=x,yy=y;
    q=val[x];
    r=val[y];
    if(p>=q&&p>=r){
        cout<<p;
        return 0;
    }
    ll tmp=p+r;
    bool f=1;
    while(f){
        if(val[x]<val[y])swap(x,y);
        q=val[x];
        r=val[y];
        if(b[x].empty()){
            f=0;
            continue;
        }
        if(p>=q&&p>=r){
            f=0;
            continue;
        }
        int mx=b[x][0];
        for(auto u:b[x]){
            if(val[u]>val[mx])mx=u;
        }
        if(p+q-val[mx]>=q){
            f=0;
            continue;
        }
        p+=q-val[mx];
        x=mx;
    }
    ll ans=max(p,max(q,r));
    q=0;r=val[xx];
    f=1;
    while(f){
        if(b[xx].empty()){
            f=0;
            continue;
        }
        int mx=b[xx][0];
        for(auto u:b[xx]){
            if(val[u]>val[mx])mx=u;
        }
        r-=val[mx];
        q=val[mx];
        xx=mx;
        ans=min(ans,max(tmp,max(r,q)));
    }
    cout<<ans;
    return 0;
}
/*
6
10 20 25 40 30 30
1 3
3 2
4 6
4 3
4 5
*/