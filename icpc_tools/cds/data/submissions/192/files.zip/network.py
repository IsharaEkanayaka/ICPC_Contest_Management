n = list(map(int,input().split()))
x = n[0]
y = n[1]
costs = []
answers = []

for i in range(x):
    answer = []
    for j in range(y):
        answer.append(1000)  
    cost = list(map(int,input().split()))
    costs.append(cost)
    answers.append(answer)

for i in range(x):
    flag = 0
    min = 1000
    min_index = []
    for j in range(y):
        if(costs[i][j] < min):
            min_index = [i,j]
            min = costs[i][j]
        
    if(flag == 0):
        answers[min_index[0]][min_index[1]]  = min

for i in range(y):
    flag = 0
    min = 1000
    min_index = []
    for j in range(x):
        if(costs[j][i] < min):
            min_index = [j,i]
            min = costs[j][i]
        if answers[j][i] < 1000:
            flag =1

    if(flag == 0):
        answers[min_index[0]][min_index[1]]  = min

for i in range(x):
    flag = 0
    min = 1000
    min_index = []
    for j in range(y):
        if(costs[i][j] < min):
            min_index = [i,j]
            min = costs[i][j]
        if answers[i][j] < 1000:
            flag =1

    if(flag == 0):
        answers[min_index[0]][min_index[1]]  = min

total_cost = 0

for i in range(x):
    for j in range(y):
        if(answers[i][j] != 1000 ):
            total_cost += answers[i][j]

print(total_cost)

 


