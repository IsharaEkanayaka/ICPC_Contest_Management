import sys

def solve():
    input_data = sys.stdin.read().split()

    iterater = iter(input_data)

    T  = int(next(iterater))

    for _ in range(T):
        n = int(next(iterater)) 
        a= [] 
        for i in range(n):
            a.append(int(next(iterater)))
        def sum(n,list):
            powers=[0]*n
            for i in range(n):
                y = list[i]
                x = 0
                for k in range(n):
                    x+=abs(a[i]-a[k])+1
                    powers[i] = x
            return powers

        print(*(sum(n, a))) 


if __name__ == "__main__":
    solve()

             
