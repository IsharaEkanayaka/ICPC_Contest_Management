#include <bits/stdc++.h>
#define pb push_back
#define mp pake_pair
#define f first
#define s second
#define vi vector<int>
#define vll vector<ll>

using namespace std;
mt19937 rnd(chrono::steady_clock::now().time_since_epoch().count());

typedef long long ll;
typedef long double ld;
const int MOD = 1e9 + 7;
const int I_MAX = INT_MAX;
const int I_MIN = INT_MIN;
const unsigned int UI_MAX = UINT_MAX;
const ll LL_MAX = LLONG_MAX;
const ll LL_MIN = LLONG_MIN;
const unsigned long long ULL_MAX = ULLONG_MAX;

int solve()
{
    int n, m; cin >> n >> m; 
    vector<vi> g(n, vi(m));
    for (int i=0; i<n; i++) {
        for (int j=0; j<m; j++) {
            cin >> g[i][j];
        }
    }

    set<int> s;
    ll ans=0;
    for (int i=0; i<n; i++) {
        int mn=1e9;
        int col=-1;
        for (int j=0; j<m; j++) {
            if (g[i][j] < mn) {
                col=j;
                mn=min(mn, g[i][j]);
            }
        }
        s.insert(col);
        ans += mn;
    }
    for (int i=0; i<m; i++) {
        if (s.find(i) == s.end()) {
            int mn=1e9;
            for (int j=0; j<n; j++) {
                mn = min(mn, g[j][i]);
            }
            if (count(g[i].begin(), g[i].end(), mn) == 1) {
                ans += mn;
            }
        }
    }
    cout << ans << endl;
    return 0;
}

int32_t main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    int TET = 1;
    // cin>>TET;

    for (int i = 1; i <= TET; i++)
    {
        if (solve())
        {
            break;
        }
    }
}